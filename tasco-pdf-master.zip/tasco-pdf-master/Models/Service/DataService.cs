﻿using System.Collections.Generic;
using System.Transactions;
using tasco_pdf.Models.Dao;

namespace tasco_pdf.Models.Service
{
    public class DataService
    {
        private DataDao dataDao = new DataDao();

        public UploadInfo GetUploadInfo(String uploadId) { return dataDao.SelectUploadInfo(uploadId); }

        // 템플릿 영역 정보 조회
        public List<PdfList> GetTemplateAreaInfo(String templateId)
        {
            List<PdfList> pdfList = new List<PdfList>();

            List<int> page = dataDao.SelectTemplateAreaPage(templateId);
            for (int i = 0; i < page.Count; i++)
            {
                PdfList pdf = new PdfList();

                pdf.PdfAreaList = dataDao.SelectTemplateAreaInfo(templateId, page[i]);
                pdf.Page = page[i];
                pdfList.Add(pdf);
            }

            return pdfList;
        }

        public int SetTemplateAreaInfo(List<PdfAreaInfo> pdfAreaInfos)
        {
            dataDao.DeleteTemplateAreaInfo(pdfAreaInfos[0].TemplateId);
            return dataDao.InsertTemplateAreaInfo(pdfAreaInfos);
        }

        public int RemoveTemplateInfo(String templateId) { return dataDao.DeleteTemplateInfo(templateId); }

        public List<ParserInfo> GetTemplateListInfo(String userId) { return dataDao.SelectTemplateListInfo(userId); }

        public ParserInfo GetTemplateInfo(String templateId) { return dataDao.SelectTemplateInfo(templateId); }

        public int SetTemplateInfo(TemplateInfo templateInfo)
        {
            int rtnVal = -1;
            if (templateInfo.TemplateId == null || templateInfo.TemplateId == String.Empty)
            {
                rtnVal = dataDao.InsertTemplateInfo(templateInfo);
            }
            else
            {
                rtnVal = dataDao.UpdateTemplateInfo(templateInfo);
            }

            return rtnVal;
        }

        public String CheckTemplateInfo(String tester, String testItem, String testType)
        {
            TemplateInfo templateInfo = new TemplateInfo();
            templateInfo.Tester = tester;
            templateInfo.TestItem = testItem;
            templateInfo.TestType = testType;

            return dataDao.SelectTemplateInfoByTest(templateInfo);
        }

        public int RemoveUploadInfo(String uploadId)
        {
            int rtnVal = -1;

            UploadInfo uploadInfo = dataDao.SelectUploadInfo(uploadId);
            try
            {
                File.Delete(uploadInfo.DestFilename); //삭제 테스트 필요
            }
            catch (IOException e)
            {
                // handle exception
            }

            rtnVal = dataDao.DeleteUploadInfo(uploadId);
            return rtnVal;
        }

        public int SetUploadInfo(UploadInfo uploadInfo) { return dataDao.InsertUploadInfo(uploadInfo); }

        public List<testkey> getTestImageKeyList() { return dataDao.GetTestImageKeyList(); }

        public List<testkey> getTestKeyList() { return dataDao.GetTestKeyList(); }

        public List<testkey> getTestTypeList() { return dataDao.GetTestTypeList(); }

        public List<testitemmaster> getTestItemList() { return dataDao.GetTestItemList(); }

        public List<tester> getTesterList() { return dataDao.GetTesterList(); }
    }
}
