﻿using Microsoft.EntityFrameworkCore.Migrations;
using PDFiumSharp;
using System.Drawing;
using System.Drawing.Imaging;
using tasco_pdf.Common;
using tasco_pdf.Models.Dao;

namespace tasco_pdf.Models.Service
{
    public class PdfImageService
    {
        public Result GetPdfData(ParserInfo parserInfo, float x, float y, float width, float height, int page)
        {
            Result result = new Result();
            result.Code = "SUCCESS";

            PdfDocument pdf = null;
            Image img = null;
            Bitmap bmpImage = null;
            RectangleF cropArea = new RectangleF(x, y, width, height);
            int zoom = 2; //확대 배수

            try
            {
                //pdf = new PdfDocument("D:\\home\\site\\wwwroot\\wwwroot\\pdf\\PRE1fold1-lcd.pdf");
                //pdf = new PdfDocument("D:\\Dev\\Projects\\tasco\\pdf\\tasco-pdf\\wwwroot\\pdf\\PRE1fold1-lcd.pdf");
                pdf = new PdfDocument(parserInfo.DestFilename);

                var pdfPage = pdf.Pages[page - 1];
                int sheetWidth = (int)pdfPage.Width;
                int sheetHeight = (int)pdfPage.Height;
                int startingImageWidth = sheetWidth * zoom;
                int startingImageHeight = sheetHeight * zoom;

                using (var bitmap = new PDFiumBitmap(startingImageWidth, startingImageHeight, true))
                {
                    //배경 흰색 설정
                    PDFiumSharp.Types.FPDF_COLOR background = new PDFiumSharp.Types.FPDF_COLOR(255, 255, 255, 255);
                    bitmap.Fill(background);
                    pdfPage.Render(bitmap);

                    using (var memoryStreamBmp = new MemoryStream())
                    {
                        bitmap.Save(memoryStreamBmp);

                        using (var imageBmp = System.Drawing.Image.FromStream(memoryStreamBmp))
                        {
                            // crop the image
                            int cropX = (int)(x * zoom);
                            int cropY = (int)(y * zoom);
                            int cropWidth = (int)(width * zoom);
                            int cropHeight = (int)(height * zoom);

                            Bitmap croppedImage = ((Bitmap)imageBmp).Clone(new System.Drawing.Rectangle(cropX, cropY, cropWidth, cropHeight), imageBmp.PixelFormat);

                            using (var memoryStreamImg = new MemoryStream())
                            {
                                croppedImage.Save(memoryStreamImg, System.Drawing.Imaging.ImageFormat.Png);
                                System.Drawing.Image image = System.Drawing.Image.FromStream(memoryStreamImg);
                                var imgBytes = memoryStreamImg.ToArray();
                                //docObj.ImageBase64 = Convert.ToBase64String(imgBytes);
                                var strBase64 = Convert.ToBase64String(imgBytes);
                                result.Data = strBase64;
                            };
                        }
                    }
                }
            } 
            catch(Exception ex) 
            {
                result.Code = "ERROR";
                Console.WriteLine(ex.Message);
            }

            if (bmpImage != null) { bmpImage.Dispose(); }
            if (img != null) { img.Dispose(); }
            if (pdf != null) { pdf.Close(); }

            return result;
        }

        public void GetPdfSize(ParserInfo parserInfo)
        {
            this.GetPdfSizeByFilename(parserInfo.DestFilename, parserInfo);
        }

        public void GetPdfSizeByFilename(String destFilename, ParserInfo parserInfo)
        {
            Result result = new Result();
            result.Code = "SUCCESS";

            PdfDocument pdf = null;

            try
            {
                //pdf = PdfiumViewer.PdfDocument.Load("D:\\home\\site\\wwwroot\\wwwroot\\pdf\\PRE1fold1-lcd.pdf");
                //pdf = PdfiumViewer.PdfDocument.Load("D:\\Dev\\Projects\\tasco\\pdf\\tasco-pdf\\wwwroot\\pdf\\PRE1fold1-lcd.pdf");
                pdf = new PdfDocument(destFilename);

                parserInfo.Width = (float)pdf.Pages[0].Width;
                parserInfo.Height = (float)pdf.Pages[0].Height;
            }
            catch (Exception ex)
            {
                result.Code = "ERROR";
                Console.WriteLine(ex.Message);
            }

            if (pdf != null) { pdf.Close(); }
        }
    }
}
