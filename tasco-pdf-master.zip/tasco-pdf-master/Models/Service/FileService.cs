﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Primitives;
using System.Drawing;
using System.Text;
using tasco_pdf.Common;
using tasco_pdf.Models.Dao;

namespace tasco_pdf.Models.Service
{
    public class FileService
    {
       private DataService dataService = new DataService();
       private readonly string _upload_path = "upload";
       JsonParser jsonParser = new JsonParser();

        public Result FileProcess(string webRootPath, IFormFile file)
        {
            Result result = new Result();

            // 파일 업로드 경로 upload\yyyy\mm\dd
            // 년/월/일 폴더 생성
            DateTime today = DateTime.Now;
            StringBuilder sbPath = new StringBuilder();
            sbPath.Append(_upload_path);
            sbPath.Append(Path.DirectorySeparatorChar);
            sbPath.Append(today.Year.ToString("0000"));
            sbPath.Append(Path.DirectorySeparatorChar);
            sbPath.Append(today.Month.ToString("00"));
            sbPath.Append(Path.DirectorySeparatorChar);
            sbPath.Append(today.Day.ToString("00"));

            // 파일 업로드 경로 확인
            string realPath = webRootPath + Path.DirectorySeparatorChar + sbPath.ToString();
            DirectoryInfo directoryInfo = new DirectoryInfo(realPath);
            if(!directoryInfo.Exists)
            {
                Directory.CreateDirectory(realPath);
            }

            // 업로드 파일명 변경
            string timestamp = DateTime.Now.ToString("yyyyMMddhhmmss") + Path.GetExtension(file.FileName);
            string orgFilename = file.FileName;
            string destFilename = realPath + Path.DirectorySeparatorChar + timestamp;
            string webPath = "/" + sbPath.ToString().Replace(Path.DirectorySeparatorChar, '/') + "/" + timestamp;

            Console.WriteLine("destFilename: " + destFilename);
            Console.WriteLine("webPath: " + webPath);

            //파일명 타임스템프로 생성
            if (file.Length > 0)
            {
                StreamReader reader = new StreamReader(file.OpenReadStream());
                string filePath = destFilename;

                using (var stream = System.IO.File.Create(destFilename))
                {
                    file.CopyTo(stream);
                    stream.Flush();
                }
            }

            // 업로드 파일 정보 저장
            UploadInfo uploadInfo = new UploadInfo();
            uploadInfo.OrgFilename = orgFilename;
            uploadInfo.DestFilename = destFilename;
            uploadInfo.WebPath = webPath;
            int rtnVal = dataService.SetUploadInfo(uploadInfo);
            if (rtnVal == 0)
            {
                result.Code = "ERROR";
                return result;
            }

            result.Code = "SUCCESS";
            result.Data = uploadInfo;

            return result;
        }

        public async Task<Result> FileProcess(List<IFormFile> files)
        {
            Result result = new Result();
            long size = files.Sum(f => f.Length);

            foreach (IFormFile formFile in files)
            {
                if (formFile.Length > 0)
                {
                    string filePath = Path.GetTempFileName();
                    Console.Write(filePath);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await formFile.CopyToAsync(stream);
                    }
                }
            }

            result.Code = "SUCCESS";
            return result;
        }
    }
}
