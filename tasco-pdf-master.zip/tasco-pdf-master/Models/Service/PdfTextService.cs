﻿using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using iText.Kernel.Pdf.Canvas.Parser.Data;
using iText.Kernel.Pdf.Canvas.Parser.Filter;
using iText.Kernel.Pdf.Canvas.Parser.Listener;
using System;
using System.Text;
using tasco_pdf.Common;
using tasco_pdf.Models.Dao;

namespace tasco_pdf.Models.Service
{
    public class PdfTextService
    {
        public Result GetPdfData(ParserInfo parserInfo, float x, float y, float width, float height, int page)
        {
            Result result = new Result();
            result.Code = "SUCCESS";

            // PDF 영역을 맞춰서 잡는 경우 text 영역이 벗어날 수 있음 1px 증가
            float inc = 1;
            x += inc;
            y += inc;
            width += inc;
            height += inc;

            float pdfHeight = parserInfo.Height;
            float pdfY = pdfHeight - (y + height);
            y = (float)Math.Truncate(pdfY);

            PdfDocument pdf = null;
            Rectangle rectangle = new Rectangle(x, y, width, height); //왼쪽 아래가 0,0

            try
            {
                //pdf = new PdfDocument(new PdfReader("D:\\home\\site\\wwwroot\\wwwroot\\pdf\\PRE1fold1-lcd.pdf"));
                //pdf = new PdfDocument(new PdfReader("D:\\Dev\\Projects\\tasco\\pdf\\tasco-pdf\\wwwroot\\pdf\\PRE1fold1-lcd.pdf"));
                pdf = new PdfDocument(new PdfReader(parserInfo.DestFilename));

                TextRegionEventFilter regionFilter = new TextRegionEventFilter(rectangle);
                ITextExtractionStrategy position = new FilteredTextEventListener(new LocationTextExtractionStrategy(), regionFilter);
                RectangleTextExtraction rectangleTextExtraction = new RectangleTextExtraction(position, rectangle); // Text별 이벤트 발생

                //string str = PdfTextExtractor.GetTextFromPage(pdf.GetPage(page), position);
                string str = PdfTextExtractor.GetTextFromPage(pdf.GetPage(page), rectangleTextExtraction);
                result.Data = str;
            }
            catch (Exception ex)
            {
                result.Code = "ERROR";
                Console.WriteLine(ex.Message);
            }

            if (pdf != null) { pdf.Close(); }

            return result;
        }
    }

    class RectangleTextExtraction : ITextExtractionStrategy
    {
        private ITextExtractionStrategy _innerStrategy;
        private Rectangle _rectangle;
        public StringBuilder sb = new StringBuilder();

        public RectangleTextExtraction(ITextExtractionStrategy strategy, Rectangle rectangle)
        {
            _innerStrategy = strategy;
            _rectangle = rectangle;
        }

        public void EventOccurred(IEventData iEventData, EventType eventType)
        {
            if (eventType != EventType.RENDER_TEXT) return;

            TextRenderInfo textRenderInfo = (TextRenderInfo)iEventData;
            foreach (TextRenderInfo textInfo in textRenderInfo.GetCharacterRenderInfos())
            {
                Rectangle rect = new CharacterRenderInfo(textInfo).GetBoundingBox();
                if (Intersects(rect))
                {
                    sb.Append(textInfo.GetText());
                    _innerStrategy.EventOccurred(textInfo, EventType.RENDER_TEXT);
                }                    
            }
        }

        private bool Intersects(Rectangle rect)
        {
            if (_rectangle.Contains(rect))
            {
                //Console.WriteLine("rect1 x:{0} y:{0} w:{0} h:{0}", _rectangle.GetX(), _rectangle.GetY(), _rectangle.GetWidth(), _rectangle.GetHeight());
                //Console.WriteLine("rect2 x:{0} y:{0} w:{0} h:{0}", rect.GetX(), rect.GetY(), rect.GetWidth(), rect.GetHeight());
                return true;
            }
            else
                return false;
        }

        public string GetResultantText()
        {
            //return _innerStrategy.GetResultantText();
            return sb.ToString();            
        }

        public ICollection<EventType> GetSupportedEvents()
        {
            return _innerStrategy.GetSupportedEvents();
        }
    }
}
