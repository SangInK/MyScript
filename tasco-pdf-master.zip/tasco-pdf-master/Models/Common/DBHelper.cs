﻿using Microsoft.Data.SqlClient;

namespace tasco_pdf.Models.Common
{
    public class DBHelper
    {
        private static string SERVER = "sf.tascorp.co.kr,1444";
        private static string UID = "las";
        private static string PWD = "!@#$1q2w3e";
        private static string DATABASE = "RTEGMS_LAS";

        private string CONNECTIONSTRING = $"server={SERVER};uid={UID};pwd={PWD};database={DATABASE};TrustServerCertificate=True; MultipleActiveResultSets=true;";

        private SqlConnection connection { get; set; }

        public SqlConnection GetConnection()
        {
            if (connection != null)
            {
                return connection;
            }
            else
            { 
                return new SqlConnection(CONNECTIONSTRING);
            }
        }
    }
}
