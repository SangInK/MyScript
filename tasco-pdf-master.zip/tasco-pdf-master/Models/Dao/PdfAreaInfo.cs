﻿using System.Security.AccessControl;

namespace tasco_pdf.Models.Dao
{
    public class PdfAreaInfo
    {
        public String TemplateAreaId { get; set; }
        public String TemplateId { get; set; }
        public int AreaOrder { get; set; }
        public String TestKey { get; set; }

        public string common_part_nm { get; set; }
        public String AreaType { get; set; }

        public int PdfPage { get; set; }

        public float AreaX { get; set; }
        public float AreaY { get; set; }
        public float AreaWidth { get; set; }
        public float AreaHeight { get; set; }
        public String AreaData { get; set; }
    }
}
