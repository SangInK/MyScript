﻿namespace tasco_pdf.Models.Dao
{
    public partial class testitemmaster
    {
        public string testitem_cd { get; set; }

        public string testitem_nm { get; set; }

    }
}
