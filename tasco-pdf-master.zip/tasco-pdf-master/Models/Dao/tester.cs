namespace tasco_pdf.Models.Dao
{
    public partial class tester
    {
        public string tester_cd { get; set; }

        public string tester_nm { get; set; }

    }
}