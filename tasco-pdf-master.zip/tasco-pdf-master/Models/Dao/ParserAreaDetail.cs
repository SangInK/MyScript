﻿namespace tasco_pdf.Models.Dao
{
    // view submit
    public class ParserAreaDetail
    {
        public string? areaType { get; set; }
        public string? testKey { get; set; }
        public float? areaX { get; set; }
        public float? areaY { get; set; }
        public float? areaWidth { get; set; }
        public float? areaHeight { get; set; }
    }
}
