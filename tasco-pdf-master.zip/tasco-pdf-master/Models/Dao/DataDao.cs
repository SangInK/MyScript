﻿using Dapper;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.Data;
using System.Diagnostics.Metrics;
using System.Text;
using tasco_pdf.Models.Common;

namespace tasco_pdf.Models.Dao
{
    public class DataDao : DBHelper
    {
        // 템플릿 페이지 목록 조회
        public List<int> SelectTemplateAreaPage(String templateId)
        {
            List<int> rtnVal = null;

            using (var conn = base.GetConnection())
            {
                String query = @"
                    select PdfPage
                    from TemplateAreaInfo a
                    where a.TemplateId = @TemplateId
                    group by a.PdfPage
                    order by a.PdfPage
                ";

                var param = new DynamicParameters();
                param.Add("@TemplateId", value: templateId, dbType: DbType.String);

                conn.Open();
                rtnVal = conn.Query<int>(query, param, commandType: CommandType.Text).ToList();
            }

            return rtnVal;
        }

        // 템플릿 페이지별 영역 정보 조회 
        public List<PdfAreaInfo> SelectTemplateAreaInfo(String templateId, int pdfPage)
        {
            List<PdfAreaInfo> rtnVal = null;

            using (var conn = base.GetConnection())
            {
                String query = @"
                    select 
	                    a.TemplateAreaId,
	                    a.TemplateId,
	                    a.AreaOrder,
	                    a.TestKey,
	                    b.common_part_nm,
	                    a.AreaType,
	                    a.AreaX,
	                    a.AreaY,
	                    a.AreaWidth,
	                    a.AreaHeight,
	                    a.PdfPage	
                    from TemplateAreaInfo a
                    left outer JOIN (
	                    select 
		                    common_part_cd,
		                    common_part_nm
	                    from
		                    dbo.common
	                    where
		                    use_yn = 'Y'
	                    and 
		                    common_cd = @common_cd ) b 
                    on
	                    a.TestKey = b.common_part_cd
                    where
	                    a.TemplateId = @TemplateId
                    and
	                    a.PdfPage = @PdfPage
                    order by a.AreaOrder asc
                ";

                var param = new DynamicParameters();
                param.Add("@common_cd", value: "QC067", dbType: DbType.String);
                param.Add("@TemplateId", value: templateId, dbType: DbType.String);
                param.Add("@PdfPage", value: pdfPage, dbType: DbType.String);

                conn.Open();
                rtnVal = conn.Query<PdfAreaInfo>(query, param, commandType: CommandType.Text).ToList();
            }

            return rtnVal;
        }

        // 템플릿 영역 정보 삭제
        public int DeleteTemplateAreaInfo(String templateId)
        {
            int rtnVal = -1;

            using (var conn = base.GetConnection())
            {
                StringBuilder sb = new StringBuilder();
                conn.Open();

                sb.Append(" delete from TemplateAreaInfo where TemplateId = '" + templateId + "' ");

                rtnVal = conn.Execute(sb.ToString(), commandType: CommandType.Text);
                conn.Close();
            }

            return rtnVal;
        }

        // 템플릿 영역 정보 저장
        public int InsertTemplateAreaInfo(List<PdfAreaInfo> pdfAreaInfos) 
        {
            int rtnVal = -1;

            using (var conn = base.GetConnection())
            {
                conn.Open();
                string query = string.Empty;
                
                foreach (PdfAreaInfo pdfAreaInfo in pdfAreaInfos) 
                {
                    // key 생성
                    query = @"
                        select FORMAT(CAST(ISNULL(MAX(TemplateAreaId), '00000000') AS INT) + 1, '00000000') 
                        from TemplateAreaInfo
                    ";
                    pdfAreaInfo.TemplateAreaId = conn.QuerySingle<String>(query, commandType: CommandType.Text);

                    query = @"
                        insert into TemplateAreaInfo (TemplateAreaId, TemplateId, AreaOrder, TestKey, AreaType, AreaX, AreaY, AreaWidth, AreaHeight, RegDttm, PdfPage) 
                        values ( @TemplateAreaId, @TemplateId, @AreaOrder, @TestKey, @AreaType, @AreaX, @AreaY, @AreaWidth, @AreaHeight, CURRENT_TIMESTAMP, @PdfPage )
                    ";

                    // 값 입력
                    var param = new DynamicParameters();
                    param.Add("@TemplateAreaId", value: pdfAreaInfo.TemplateAreaId, dbType: DbType.String);
                    param.Add("@TemplateId", value: pdfAreaInfo.TemplateId, dbType: DbType.String);
                    param.Add("@AreaOrder", value: pdfAreaInfo.AreaOrder, dbType: DbType.Int32);
                    param.Add("@TestKey", value: pdfAreaInfo.TestKey, dbType: DbType.String);
                    param.Add("@AreaType", value: pdfAreaInfo.AreaType, dbType: DbType.String);
                    param.Add("@AreaX", value: pdfAreaInfo.AreaX, dbType: DbType.Decimal);
                    param.Add("@AreaY", value: pdfAreaInfo.AreaY, dbType: DbType.Decimal);
                    param.Add("@AreaWidth", value: pdfAreaInfo.AreaWidth, dbType: DbType.Decimal);
                    param.Add("@AreaHeight", value: pdfAreaInfo.AreaHeight, dbType: DbType.Decimal);
                    param.Add("@PdfPage", value: pdfAreaInfo.PdfPage, dbType: DbType.Decimal);

                    rtnVal = conn.Execute(query, param, commandType: CommandType.Text);

                }
            }

            return rtnVal;
        }

        // 템플릿 목록 조회
        public List<ParserInfo> SelectTemplateListInfo(String userId)
        {
            List<ParserInfo> parserInfo = new List<ParserInfo>();

            using (var conn = base.GetConnection())
            {
                String query = @"
                    select a.TemplateId
	                    , a.Tester
	                    , b.tester_nm as TesterKrName
	                    , a.TestItem
	                    , c.testitem_nm as TestItemKrName
	                    , a.TestType
	                    , d.common_part_nm as TestTypeKrName
	                    , e.UploadId
	                    , e.OrgFilename
                    from TemplateInfo a
	                    , tester b
	                    , testitemmaster c
	                    , common d
	                    , UploadInfo e
                    where a.UseYn = 'Y'
                    /* and a.UserId = 'Y' */
                    and a.Tester = b.tester_cd
                    and a.TestItem = c.testitem_cd
                    and a.UploadId = e.UploadId
                    and a.TestType = d.common_part_cd
                    and d.use_yn = 'Y'
                    and d.common_cd = 'QC078'
                  order by a.TemplateId desc
                ";

                parserInfo = conn.Query<ParserInfo>(query, commandType: CommandType.Text).ToList();
            }

            return parserInfo;
        }

        // 템플릿 정보 조회 (시험 기기, 시험 항목, 시험 구분 기준)
        public String SelectTemplateInfoByTest(TemplateInfo templateInfo)
        {
            var templateId = String.Empty;

            using (var conn = base.GetConnection())
            {
                String query = @" SELECT ISNULL(TemplateId, '')
                                    from TemplateInfo
                                    where UseYn = 'Y'
                                    and Tester = @Tester
                                    and TestItem = @TestItem
                                    and TestType = @TestType ";

                var param = new DynamicParameters();
                param.Add("@Tester", value: templateInfo.Tester, dbType: DbType.String);
                param.Add("@TestItem", value: templateInfo.TestItem, dbType: DbType.String);
                param.Add("@TestType", value: templateInfo.TestType, dbType: DbType.String);

                templateId = conn.QueryFirstOrDefault<String>(query, param, commandType: CommandType.Text);
            }

            return templateId;
        }

        // 템플릿 정보 + 템플릿 파일 정보 조회
        public ParserInfo SelectTemplateInfo(String templateId) 
        {
            ParserInfo parserInfo = new ParserInfo();

            using (var conn = base.GetConnection())
            {
                String query = @"
                    select a.TemplateId
	                    , a.Tester
	                    , b.tester_nm as TesterKrName
	                    , a.TestItem
	                    , c.testitem_nm as TestItemKrName
	                    , a.TestType
	                    , e.common_part_nm as TestTypeKrName
	                    , a.UserId
	                    , a.UploadId
	                    , d.OrgFilename
	                    , d.DestFilename
	                    , d.WebPath
                    from TemplateInfo a
	                    , tester b
	                    , testitemmaster c
	                    , UploadInfo d
	                    , common e
                    where a.TemplateId = @TemplateId
                    and a.UseYn = 'Y'
                    and a.Tester = b.tester_cd
                    and a.TestItem = c.testitem_cd
                    and a.UploadId = d.UploadId
                    and a.TestType = e.common_part_cd
                    and e.use_yn = 'Y'
                    and e.common_cd = 'QC078'
                ";

                var param = new DynamicParameters();
                param.Add("@TemplateId", value: templateId, dbType: DbType.String);

                parserInfo = conn.QuerySingle<ParserInfo>(query, param, commandType: CommandType.Text);
            }

            return parserInfo;
        }

        // 템플릿 기본 정보 삭제 (UseYn)
        public int DeleteTemplateInfo(String templateId)
        {
            int rtnVal = -1;

            using (var conn = base.GetConnection())
            {
                String query = @"
                    update TemplateInfo
                    set UseYn = 'N'
                    where TemplateId = @TemplateId
                ";

                var param = new DynamicParameters();
                param.Add("@TemplateId", value: templateId, dbType: DbType.String);

                rtnVal = conn.Execute(query, param, commandType: CommandType.Text);
            }


            return rtnVal;
        }

        // 템플릿 기본 정보 수정
        public int UpdateTemplateInfo(TemplateInfo templateInfo)
        {
            int rtnVal = -1;

            using (var conn = base.GetConnection())
            {
                String query = @"
                    update TemplateInfo
                    set Tester = @Tester
                        , TestItem = @TestItem
                        , TestType = @TestType
                        , UploadId = @UploadId
                        , EditDttm = CURRENT_TIMESTAMP
                    where TemplateId = @TemplateId
                ";

                var param = new DynamicParameters();
                param.Add("@Tester", value: templateInfo.Tester, dbType: DbType.String);
                param.Add("@TestItem", value: templateInfo.TestItem, dbType: DbType.String);
                param.Add("@TestType", value: templateInfo.TestType, dbType: DbType.String);
                param.Add("@UploadId", value: templateInfo.UploadId, dbType: DbType.String);
                param.Add("@TemplateId", value: templateInfo.TemplateId, dbType: DbType.String);

                rtnVal = conn.Execute(query, param, commandType: CommandType.Text);
            }

            return rtnVal;
        }

        // 템플릿 기본 정보 저장
        public int InsertTemplateInfo(TemplateInfo templateInfo) 
        {
            int rtnVal = -1;

            using (var conn = base.GetConnection())
            {                
                conn.Open();

                // key 생성
                string query = @"
                    select FORMAT(CAST(ISNULL(MAX(TemplateId), '00000000') AS INT) + 1, '00000000') 
                    from TemplateInfo
                ";
                templateInfo.TemplateId = conn.QuerySingle<String>(query, commandType: CommandType.Text);

                // 값 입력
                query = @"
                    insert into TemplateInfo ( TemplateId, Tester, TestItem, TestType, UploadId, RegDttm)
                    values ( @TemplateId, @Tester, @TestItem, @TestType, @UploadId, CURRENT_TIMESTAMP )
                ";

                var param = new DynamicParameters();
                param.Add("@TemplateId", value: templateInfo.TemplateId, dbType: DbType.String);
                param.Add("@Tester", value: templateInfo.Tester, dbType: DbType.String);
                param.Add("@TestItem", value: templateInfo.TestItem, dbType: DbType.String);
                param.Add("@TestType", value: templateInfo.TestType, dbType: DbType.String);
                param.Add("@UploadId", value: templateInfo.UploadId, dbType: DbType.String);

                rtnVal = conn.Execute(query, param, commandType: CommandType.Text);
            }

            return rtnVal;
        }

        // 파일 정보 삭제
        public int DeleteUploadInfo(String uploadId)
        {
            int rtnVal = -1;

            using (var conn = base.GetConnection())
            {
                String query = @"
                    DELETE FROM UploadInfo
                    WHERE UploadId = @UploadId;
                ";

                var param = new DynamicParameters();
                param.Add("@UploadId", value: uploadId, dbType: DbType.String);

                rtnVal = conn.Execute(query, param, commandType: CommandType.Text);
            }

            return rtnVal;
        }

        // 파일 정보 저장
        public UploadInfo SelectUploadInfo(String uploadId) 
        {
            UploadInfo uploadInfo = new UploadInfo();

            using (var conn = base.GetConnection())
            {
                String query = @"
                    select UploadId
                        , OrgFilename
                        , DestFilename
                        , WebPath
                     from UploadInfo
                    where UploadId = @uploadId
                ";

                var param = new DynamicParameters();
                param.Add("@UploadId", value: uploadId, dbType: DbType.String);

                uploadInfo = conn.QuerySingle<UploadInfo>(query, param, commandType: CommandType.Text);
            }

            return uploadInfo;
        }


        // 파일 업로드 정보 저장
        public int InsertUploadInfo(UploadInfo uploadInfo)
        {
            int rtnVal = -1;

            using (var conn = base.GetConnection())
            {
                conn.Open();

                // key 생성
                string query = @"
                    select FORMAT(CAST(ISNULL(MAX(UploadId), '00000000') AS INT) + 1, '00000000') 
                    from UploadInfo
                ";
                uploadInfo.UploadId = conn.QuerySingle<String>(query, commandType: CommandType.Text);

                // 값 입력
                query = @"
                    insert into UploadInfo ( UploadId, OrgFilename, DestFilename, RegDttm, WebPath)
                    values ( @UploadId, @OrgFilename, @DestFilename, CURRENT_TIMESTAMP, @WebPath )
                ";

                var param = new DynamicParameters();
                param.Add("@UploadId", value: uploadInfo.UploadId, dbType: DbType.String);
                param.Add("@OrgFilename", value: uploadInfo.OrgFilename, dbType: DbType.String);
                param.Add("@DestFilename", value: uploadInfo.DestFilename, dbType: DbType.String);
                param.Add("@WebPath", value: uploadInfo.WebPath, dbType: DbType.String);

                rtnVal = conn.Execute(query, param, commandType: CommandType.Text);
            }

            return rtnVal;
        }


        /// <summary>
        /// 시험서 이미지 key 조회
        /// </summary>  
        public List<testkey> GetTestImageKeyList()
        {
            List<testkey> rtnVal = null;

            using (var conn = base.GetConnection())
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("select common_part_cd, common_part_nm ");
                sb.Append("from dbo.common ");
                sb.Append("where use_yn = 'Y' ");
                sb.Append("and common_cd = @common_cd ");
                sb.Append("and common_part_nm like '%이미지%' ");
                sb.Append("order by common_part_nm ASC ");

                var p = new DynamicParameters();
                p.Add("@common_cd", value: "QC067", dbType: DbType.String);

                conn.Open();
                rtnVal = conn.Query<testkey>(sb.ToString(), p, commandType: CommandType.Text).ToList();
            }

            return rtnVal;
        }

        /// <summary>
        /// 시험서 key 조회
        /// </summary>  
        public List<testkey> GetTestKeyList()
        {
            List<testkey> rtnVal = null;

            using (var conn = base.GetConnection())
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("select common_part_cd, common_part_nm ");
                sb.Append("from dbo.common ");
                sb.Append("where use_yn = 'Y' ");
                sb.Append("and common_cd = @common_cd ");
                sb.Append("and common_part_nm not like '%이미지%' ");
                sb.Append("order by common_part_nm ASC ");

                var p = new DynamicParameters();
                p.Add("@common_cd", value: "QC067", dbType: DbType.String);

                conn.Open();
                rtnVal = conn.Query<testkey>(sb.ToString(), p, commandType: CommandType.Text).ToList();
            }

            return rtnVal;
        }


        /// <summary>
        /// 시험서 구분 조회
        /// </summary>  
        public List<testkey> GetTestTypeList()
        {
            List<testkey> rtnVal = null;

            using (var conn = base.GetConnection())
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("select common_part_cd, common_part_nm ");
                sb.Append("from dbo.common ");
                sb.Append("where use_yn = 'Y' ");
                sb.Append("and common_cd = @common_cd ");
                sb.Append("order by common_part_nm ASC ");

                var p = new DynamicParameters();
                p.Add("@common_cd", value: "QC078", dbType: DbType.String);

                conn.Open();
                rtnVal = conn.Query<testkey>(sb.ToString(), p, commandType: CommandType.Text).ToList();
            }

            return rtnVal;
        }


        /// <summary>
        /// 시험항목 조회
        /// </summary>  
        public List<testitemmaster> GetTestItemList()
        {
            List<testitemmaster> rtnVal = null;

            using (var conn = base.GetConnection())
            {
                string sql = "select testitem_cd, testitem_nm from dbo.testitemmaster where use_yn = 'Y' and testitem_nm <> '' order by testitem_nm ASC";
                var p = new DynamicParameters();

                conn.Open();
                rtnVal = conn.Query<testitemmaster>(sql, p, commandType: CommandType.Text).ToList();
            }

            return rtnVal;
        }

        /// <summary>
        /// 시험기기 조회
        /// </summary>
        public List<tester> GetTesterList()
        {
            List<tester> rtnVal = null;

            using (var conn = base.GetConnection())
            {
                string sql = "select tester_cd, tester_nm from dbo.tester where tester_use_gb = 'Y' order by tester_nm ASC";
                var p = new DynamicParameters();

                conn.Open();
                rtnVal = conn.Query<tester>(sql, p, commandType: CommandType.Text).ToList();
            }

            return rtnVal;
        }
        
    }
}
