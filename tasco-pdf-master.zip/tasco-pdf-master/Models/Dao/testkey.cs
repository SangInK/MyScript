﻿namespace tasco_pdf.Models.Dao
{
    public partial class testkey
    {
        public string common_part_cd { get; set; }
        public string common_part_nm { get; set; }
    }
}
