﻿namespace tasco_pdf.Models.Dao
{
    // view submit

    public class ParserAreaInfo
    {
        public string? templateId { get; set; }

        public List<PageList>? pageList { get; set; }
    }

    public class PageList
    {
        public int page { get; set; }
        public List<ParserAreaDetail>? parserAreaList { get; set; }
    }
}
