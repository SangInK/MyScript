﻿using Newtonsoft.Json;
using System.Web;

namespace tasco_pdf.Models.Dao
{
    public class ParserInfo
    {
        public String TemplateId { get; set; }

        // 기본 정보
        public string Tester { get; set; }
        public String TesterKrName { get; set; }

        public string TestItem { get; set; }
        public String TestItemKrName { get; set; }

        public string TestType { get; set; }
        public String TestTypeKrName { get; set; }
        
        // PDF 파일 위치 정보
        public string UploadId { get; set; }
        public string OrgFilename { get; set; }
        [JsonIgnore]
        public string DestFilename { get; set; }

        public string WebPath { get; set; }

        // PDF 정보
        public float Width { get; set; }
        public float Height { get; set; }

        public List<PdfList> PdfList { get; set; }
    }

    public class PdfList
    {
        public int Page { get; set; }
        public List<PdfAreaInfo>? PdfAreaList { get; set; }
    }
}
