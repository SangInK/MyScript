﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json.Serialization;

namespace tasco_pdf.Models.Dao
{
    public class TemplateInfo
    {
        //[JsonPropertyName("templateId")]
        [BindProperty(Name = "templateId")]
        public string? TemplateId { get; set; }
        
        //[JsonPropertyName("tester-select")]
        [BindProperty(Name = "tester-select")]
        public string? Tester { get; set; }

        //[JsonPropertyName("test-item-select")]
        [BindProperty(Name = "test-item-select")]
        public string? TestItem { get; set; }

        //[JsonPropertyName("test-type-select")]
        [BindProperty(Name = "test-type-select")]
        public string? TestType { get; set; }

        //[JsonPropertyName("uploadId")]
        public string? UploadId { get; set; }

        //[JsonIgnore]
        public string? UseYn { get; set; }
        
        //[JsonPropertyName("userId")]
        public string? UserId { get; set; }
    }
}
