﻿namespace tasco_pdf.Models.Dao
{
    public class UploadInfo
    {
        public String UploadId { get; set; }
        public String OrgFilename { get; set; }
        public String DestFilename { get; set; }
        public String WebPath { get; set; }
    }
}
