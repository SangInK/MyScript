//export const BASE_URL = "https://tasco.azurewebsites.net";
export const BASE_URL = "https://localhost:7296";

// 템플릿 목록 호출
export const GET_TEMPLATE_LIST = `${BASE_URL}/Parser/ParserList`;

// 시험 기기 목록 호출
export const GET_TESTER_LIST = `${BASE_URL}/Data/TesterList`;

// 시험 종류 목록 호출
export const GET_TEST_ITEM_LIST = `${BASE_URL}/Data/TestItemList`;

// 시험 구분 목록 호출
export const GET_TEST_TYPE_LIST = `${BASE_URL}/Data/TestTypeList`;

// 템플릿 기본 세팅 정보 저장
export const POST_PARSER_CONFIG = `${BASE_URL}/Parser/ParserConfigSave`;

// 템플릿 기본 세팅 정보 수정
export const POST_PARSER_CONFIG_UPDATE = `${BASE_URL}/Parser/ParserConfigUpdate`;

// 템플릿 영역 정보 삭제
export const DELETE_PARSER_CONFIG = `${BASE_URL}/Parser/ParserDelete`;

// 시험 키 목록 호출
export const GET_TEST_KEY_LIST = `${BASE_URL}/Data/TestKeyList`;

// 이미지 키 목록 호출
export const GET_TEST_IMAGE_KEY_LIST = `${BASE_URL}/Data/TestImageKeyList`;

// 선택 추출 영역 검증(PDF 영역 자료 확인)
export const VERIFY_PARSER_AREA = `${BASE_URL}/PdfTemplate/ParserArea`;

// 팀플릿 설정 정보 조회
export const GET_TEMPLATE_CONFIG_INFO = `${BASE_URL}/PdfTemplate/ParserConfigLoad`;

// 템플릿 영역 설정 정보 저장
export const POST_PARSER_AREA_CONFIG = `${BASE_URL}/PdfTemplate/ParserAreaSave`;

// 템플릿 영역 정보 및 자료 조회
export const GET_PARSER_AREA = `${BASE_URL}/PdfTemplate/ParserAreaLoad`;

// 파싱될 PDF 업로드
export const POST_PARSER_PDF_UPLOAD = `${BASE_URL}/Parser/ParserPDFUpload`;

// 업로드 파일 파싱
export const GET_PARSER_PROCESS = `${BASE_URL}/Parser/ParserProcess`;
