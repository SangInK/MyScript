let $loading;

/**
 * @description 로딩 노출
 */
export const showLoading = () => {
  $loading.style.display = "flex";
};

/**
 * @description 로딩 숨김
 */
export const hideLoading = () => {
  $loading.style.display = "none";
};

(function () {
  $loading = document.createElement("div");
  $loading.id = "loading";
  $loading.classList.add("loading");

  const spinner = document.createElement("span");
  spinner.classList.add("material-icons-outlined", "spinner");
  // spinner.innerText = "cached";

  const spinnerContainer = document.createElement("div");
  spinnerContainer.classList.add("column", "flex-center", "flex-1");

  spinnerContainer.appendChild(spinner);
  $loading.appendChild(spinnerContainer);

  document.body.appendChild($loading);
})();

window.onload = function () {};
