﻿import {
    BASE_URL,
    GET_TEST_KEY_LIST,
    GET_TEST_IMAGE_KEY_LIST,
    VERIFY_PARSER_AREA,
    GET_TEMPLATE_CONFIG_INFO,
    POST_PARSER_AREA_CONFIG,
    GET_PARSER_PROCESS,
} from "./api.js";
import { showLoading, hideLoading } from "./loading.js";
import { moveToHome, moveToSettings } from "./movePath.js";
import { getParameter } from "./util.js";
import { initTooltipEvent } from "./tooltip.js";

let loadedPdf; // 로딩된 PDF
let totalPage = -1; // PDF 전체 페이지수
let currentPageIndex = -1; // PDF 현재 페이지 인덱스

let scaleUnit = 1.8; // PDF의 화면 스케일 비율
let startX, startY, endX, endY; // 캔버스 영역 그리기 제어를 위한 마우스 시작 좌표와 종료 좌표
let draw = false; // 캔버스 영역 그리기 제어를 위한 flag

let $extractList;
let $coordinateCanvas;
let $coordinateContext;
let $verifyResult;
let $resultContainer;
let $currentPage;
let $previousButton;
let $nextButton;

let templateId; // 로딩된 템플릿 ID
let uploadId; // 로딩된 업로드 ID
let pdfPath; // 업로드된 PDF 경로
let pdfWidth; // PDF 가로길이 from Server
let pdfHeight; // PDF 세로길이 from Server
let testKeyList; // 시험 키 목록 from Server
let testImageKeyList; // 이미지 키 목록 from Server

let targetExtractIndex = -1; // 현재 편집 중으로 선택된 추출 설정값 인덱스
let targetExtractType = ""; // 현재 편집 중으로 선택된 추출 설정 타입 (image | text)
const extractData = [[]]; // 추출 영역 데이터 리스트

let coordinateList = [[]]; // 추출 영역 좌표 리스트

/**
 * @description 시험 보고서 파싱 결과 불러오기 함수
 * @param {string} templateId 템플릿 ID
 * @param {string} uploadId 업로드 ID
 */
const loadParserResult = async (templateId, uploadId) => {
    showLoading();
    const result = await fetch(
        `${GET_PARSER_PROCESS}?templateId=${templateId}&uploadId=${uploadId}`
    )
        .then((response) => response.json())
        .then((data) => {
            return data;
        })
        .catch((error) => console.log("error:", error));

    console.log(result);
    if (result) {
        const { Code, Data } = result;
        if (Code === "SUCCESS") {
            const {
                OrgFilename,
                Width,
                Height,
                Tester,
                TesterKrName,
                TestItem,
                TestItemKrName,
                TestType,
                TestTypeKrName,
                WebPath,
                PdfList,
            } = Data;
            pdfPath = `${BASE_URL}${WebPath}`;
            pdfWidth = Width;
            pdfHeight = Height;
            document.getElementById("pdf-file-name").innerText = OrgFilename;
            document.getElementById(
                "pdf-info"
            ).innerText = `${TesterKrName}/${TestItemKrName}/${TestTypeKrName}`;

            await loadPdf();

            const textResultContainer = document.createElement("div");
            const imageResultContainer = document.createElement("div");
            // PDF List 조회를 통한 결과값 생성
            if (PdfList && PdfList.length > 0) {
                PdfList.forEach((pdfItem) => {
                    const { Page, PdfAreaList } = pdfItem;
                    if (PdfAreaList && PdfAreaList.length > 0) {
                        const pageIndex = Page - 1;
                        if (
                            extractData[pageIndex] === undefined ||
                            !extractData[pageIndex]
                        ) {
                            extractData[pageIndex] = [];
                        }

                        PdfAreaList.forEach((item) => {
                            const {
                                TemplateId,
                                TemplateAreaId,
                                AreaOrder,
                                common_part_nm,
                                TestKey,
                                AreaType,
                                AreaX,
                                AreaY,
                                AreaWidth,
                                AreaHeight,
                                AreaData,
                            } = item;

                            extractData[pageIndex].push({
                                templateId: TemplateId,
                                testKey: TestKey,
                                areaType: AreaType,
                                areaX: AreaX,
                                areaY: AreaY,
                                areaWidth: AreaWidth,
                                areaHeight: AreaHeight,
                            });
                        });
                    }
                });
                console.log("Loaded Extract Data: ", extractData);
                
                loadExtractData();
            }
        }
    }
    hideLoading();
};

/**
 * @description 테스트 키 로딩 함수
 */
const loadTestKeyList = async () => {
    showLoading();
    const result = await fetch(GET_TEST_KEY_LIST)
        .then((response) => response.json())
        .then((data) => {
            return data;
        })
        .catch((error) => console.log("error:", error));
    if (result) {
        testKeyList = result;
    }
    hideLoading();
};

/**
 * @description 이미지 키 로딩 함수
 */
const loadTestImageKeyList = async () => {
    showLoading();
    const result = await fetch(GET_TEST_IMAGE_KEY_LIST)
        .then((response) => response.json())
        .then((data) => {
            return data;
        })
        .catch((error) => console.log("error:", error));
    if (result) {
        testImageKeyList = result;
    }
    hideLoading();
};

/**
 * @description 추출 값 인풋 텍스트 포맷 리턴 함수
 * @param {number} x
 * @param {number} y
 * @param {number} width
 * @param {number} height
 */
const getValueExtractInputText = (x, y, width, height) => {
    return `x:${x},y:${y},w:${width},h:${height}`;
};

/**
 * @description 추출 영역 좌표값 계산 함수
 */
const calculateExtractCoordinate = () => {
    const canvasWidth = $coordinateCanvas.width;
    const canvasHeight = $coordinateCanvas.height;
    console.log("canvas width:", canvasWidth);
    console.log("canvas height:", canvasHeight);
    let startX, startY, endX, endY;
    if (
        coordinateList[currentPageIndex][targetExtractIndex].startX <
        coordinateList[currentPageIndex][targetExtractIndex].endX
    ) {
        startX = coordinateList[currentPageIndex][targetExtractIndex].startX;
        endX = coordinateList[currentPageIndex][targetExtractIndex].endX;
    } else {
        startX = coordinateList[currentPageIndex][targetExtractIndex].endX;
        endX = coordinateList[currentPageIndex][targetExtractIndex].startX;
    }

    if (
        coordinateList[currentPageIndex][targetExtractIndex].startY <
        coordinateList[currentPageIndex][targetExtractIndex].endY
    ) {
        startY = coordinateList[currentPageIndex][targetExtractIndex].startY;
        endY = coordinateList[currentPageIndex][targetExtractIndex].endY;
    } else {
        startY = coordinateList[currentPageIndex][targetExtractIndex].endY;
        endY = coordinateList[currentPageIndex][targetExtractIndex].startY;
    }
    console.log("start x: ", startX);
    console.log("end x: ", endX);
    console.log("start y: ", startY);
    console.log("end y: ", endY);

    const convertedStartX = ((startX * pdfWidth) / canvasWidth).toFixed(2);
    const convertedEndX = ((endX * pdfWidth) / canvasWidth).toFixed(2);
    const convertedStartY = ((startY * pdfHeight) / canvasHeight).toFixed(2);
    const convertedEndY = ((endY * pdfHeight) / canvasHeight).toFixed(2);

    const x = convertedStartX;
    const y = convertedStartY;
    const width = (convertedEndX - convertedStartX).toFixed(2);
    const height = (convertedEndY - convertedStartY).toFixed(2);
    extractData[currentPageIndex][targetExtractIndex] = {
        ...extractData[currentPageIndex][targetExtractIndex],
        areaX: x,
        areaY: y,
        areaWidth: width,
        areaHeight: height,
    };
    console.log(extractData[currentPageIndex][targetExtractIndex]);
    document.getElementById(`value-extract-input-${targetExtractIndex}`).value =
        getValueExtractInputText(x, y, width, height);
};

/**
 * @description 추출 영역 초기화 함수
 */
const initExractRect = () => {
    $coordinateContext.clearRect(
        0,
        0,
        $coordinateCanvas.width,
        $coordinateCanvas.height
    ); //clear canvas
};

/**
 * @description 타겟 추출 영역 렌더링 함수
 * @param {'TEXT' | 'IMAGE'} extractType extract type
 * @param {number} index target index
 */
const renderExtractRect = (extractType, index) => {
    $coordinateContext.strokeStyle =
        extractType === "TEXT" ? "#f44336" : "#4caf50";

    if (
        extractData[currentPageIndex][index] &&
        extractData[currentPageIndex][index].areaX
    ) {
        const { areaX, areaY, areaWidth, areaHeight } =
            extractData[currentPageIndex][index];

        const canvasWidth = $coordinateCanvas.width;
        const canvasHeight = $coordinateCanvas.height;
        $coordinateContext.strokeRect(
            (areaX * canvasWidth) / pdfWidth,
            (areaY * canvasHeight) / pdfHeight,
            (areaWidth * canvasWidth) / pdfWidth,
            (areaHeight * canvasHeight) / pdfHeight
        );
    }
};

/**
 * @description 추출 영역 이벤트 등록 함수
 */
const initExtractCoordinate = () => {
    const canvasX = $coordinateCanvas.offsetLeft;
    const canvasY = $coordinateCanvas.offsetTop;
    $coordinateContext.strokeStyle =
        targetExtractType === "TEXT" ? "#f44336" : "#4caf50";
    $coordinateCanvas.addEventListener("mousedown", (e) => {
        if (targetExtractIndex !== -1) {
            coordinateList[currentPageIndex][targetExtractIndex].startX = parseInt(
                e.offsetX - canvasX
            );
            coordinateList[currentPageIndex][targetExtractIndex].startY = parseInt(
                e.offsetY - canvasY
            );
            draw = true;
        }
    });

    $coordinateCanvas.addEventListener("mousemove", (e) => {
        if (targetExtractIndex !== -1 && draw) {
            coordinateList[currentPageIndex][targetExtractIndex].endX = parseInt(
                e.offsetX - canvasX
            );
            coordinateList[currentPageIndex][targetExtractIndex].endY = parseInt(
                e.offsetY - canvasY
            );
            initExractRect();

            $coordinateContext.strokeRect(
                coordinateList[currentPageIndex][targetExtractIndex].startX,
                coordinateList[currentPageIndex][targetExtractIndex].startY,
                coordinateList[currentPageIndex][targetExtractIndex].endX -
                coordinateList[currentPageIndex][targetExtractIndex].startX,
                coordinateList[currentPageIndex][targetExtractIndex].endY -
                coordinateList[currentPageIndex][targetExtractIndex].startY
            );
        }
    });

    $coordinateCanvas.addEventListener("mouseup", (e) => {
        if (targetExtractIndex !== -1) {
            calculateExtractCoordinate();

            draw = false;
        }
    });

    /*
     * Canvas 영역으로부터 마우스 아웃 이벤트 발생 시 그리던 추출 영역 종료
     */
    // $coordinateCanvas.addEventListener("mouseout", (e) => {
    //   if (targetExtractIndex !== -1) {
    //     calculateExtractCoordinate();
    //     draw = false;
    //   }
    // });
};

/**
 * @description 페이지에 따라 기존에 설정된 추출 정보 로딩
 */
const loadExtractData = () => {
    targetExtractIndex = -1;
    targetExtractType = "";

    $extractList.innerHTML = "";
    if (!extractData[currentPageIndex]) {
        extractData[currentPageIndex] = [];
    }
    if (!coordinateList[currentPageIndex]) {
        coordinateList[currentPageIndex] = [];
    }
    console.log("make?", extractData);
    if (extractData[currentPageIndex].length > 0) {
        extractData[currentPageIndex].forEach((extractItem, index) => {
            const { areaType, testKey, areaX, areaY, areaWidth, areaHeight } =
                extractItem;
            console.log(extractItem);
            if (areaType === "TEXT") {
                handleAddTextExtract(index);
            } else if (areaType === "IMAGE") {
                handleAddImageExtract(index);
            }
            if (testKey) {
                document.getElementById(`test-key-select-${index}`).value = testKey;
            }
            if (areaX && areaY && areaWidth && areaHeight) {
                document.getElementById(`value-extract-input-${index}`).value =
                    getValueExtractInputText(areaX, areaY, areaWidth, areaHeight);
            }
        });
    }
    console.log(extractData);
};

/**
 * @description 이전 페이지 이동 가능 여부 판별
 */
const checkMovablePage = () => {
    if (currentPageIndex > 0) {
        $previousButton.disabled = false;
    } else {
        $previousButton.disabled = true;
    }

    if (currentPageIndex < totalPage - 1) {
        $nextButton.disabled = false;
    } else {
        $nextButton.disabled = true;
    }
};

/**
 * @description PDF 이전 페이지 이동
 */
const moveToPrevious = () => {
    // scaleUnit = 1.8;
    const previousPage = currentPageIndex - 1;
    if (previousPage > -1) {
        currentPageIndex = previousPage;
        checkMovablePage();
        renderPage(currentPageIndex);
        loadExtractData();
    }
};

/**
 * @description PDF 다음 페이지 이동
 */
const moveToNext = () => {
    // scaleUnit = 1.8;
    const nextPage = currentPageIndex + 1;
    if (nextPage < totalPage) {
        currentPageIndex = nextPage;
        checkMovablePage();
        renderPage(currentPageIndex);
        loadExtractData();
    }
};

/**
 * @description PDF 화면 확대 이벤트 핸들리
 */
const handleZoomIn = () => {
    scaleUnit += 0.25;
    renderPage(currentPageIndex);
};

/**
 * @description PDF 화면 축소 이벤트 핸들리
 */
const handleZoomOut = () => {
    scaleUnit -= 0.25;
    renderPage(currentPageIndex);
};

/**
 * @description PDF Page 렌더링 함수
 * @param {number} pageIndex PDF page index
 */
const renderPage = async (pageIndex) => {
    $currentPage.innerText = pageIndex + 1;
    const page = await loadedPdf.getPage(pageIndex + 1);

    const pdfCanvas = document.createElement("canvas");
    pdfCanvas.className = "pdf";
    pdfCanvas.id = "pdf-canvas";

    const pdfWrapper = document.createElement("div");
    pdfWrapper.className = "pdf-wrapper";
    pdfWrapper.id = "pdf-wrapper";
    pdfWrapper.appendChild(pdfCanvas);

    const pdfArea = document.getElementById("pdf-container");

    pdfArea.replaceChildren(pdfWrapper);

    const pdfContext = pdfCanvas.getContext("2d");

    const scale = scaleUnit;

    const viewport = page.getViewport({ scale });
    pdfCanvas.height = viewport.height;
    pdfCanvas.width = viewport.width;

    const renderContext = {
        canvasContext: pdfContext,
        viewport: viewport,
    };

    const renderTask = page.render(renderContext);

    renderTask.promise.then(function () {
        console.log("Page rendered");

        pdfWrapper.addEventListener("wheel", (event) => {
            if (event.ctrlKey) {
                event.preventDefault();

                if (event.deltaY < 0) {
                    handleZoomIn();
                } else if (event.deltaY > 0) {
                    handleZoomOut();
                }
            }
        });

        const coordinateContainer = document.createElement("div");
        coordinateContainer.className = "coordinate-container";
        coordinateContainer.id = `coordinate-container`;
        const coordinateCanvas = document.createElement("canvas");
        coordinateCanvas.id = "coordinate-canvas";
        coordinateCanvas.height = viewport.height;
        coordinateCanvas.width = viewport.width;

        coordinateContainer.appendChild(coordinateCanvas);
        pdfWrapper.appendChild(coordinateContainer);
        $coordinateCanvas = coordinateCanvas;
        $coordinateContext = coordinateCanvas.getContext("2d");
        $coordinateContext.lineWidth = 1;
        initExtractCoordinate();
    });
};

/**
 * @description PDF 파일 로드 및 초기 세팅 함수
 */
const loadPdf = async () => {
    showLoading();
    const loadingTask = pdfjsLib.getDocument(pdfPath);
    pdfjsLib.workerSrc = "/js/pdfjs-3.2.146/pdf.worker.js";
    const pdf = await loadingTask.promise
        .then(async (pdf) => pdf)
        .catch((error) => console.log("PDF Loaded Error:", error));
    if (pdf) {
        console.log("PDF loaded");
        console.log(pdf);

        totalPage = pdf.numPages;
        console.log("Total Page: ", totalPage);
        document.getElementById("total-page").innerText = totalPage;

        loadedPdf = pdf;
        currentPageIndex = 0;
        renderPage(currentPageIndex);
    }
    hideLoading();
};

/**
 * @description 테스트 키 셀렉트 변경 이벤트 핸들러
 * @param {Event} event onchange event
 * @param {number} index select element's index
 */
const handleChangeTestKey = (event, index) => {
    console.log("Selected Test Key: ", event.target.value);
    const { areaType } = extractData[currentPageIndex][index];
    console.log("Selected Area Type: ", areaType);
    extractData[currentPageIndex][index] = {
        ...extractData[currentPageIndex][index],
        testKey: event.target.value,
    };
    handleStartExtract(areaType, index);
};

/**
 * @description 이미지 라벨(이름) 변경 이벤트 핸들러
 * @param {Event} event onchange event
 * @param {number} index input element's index
 */
const handleChangeImageName = (event, index) => {
    extractData[currentPageIndex][index] = {
        ...extractData[currentPageIndex][index],
        testKey: event.target.value,
    };
};

/**
 * @description 테스트 키 셀렉트박스 생성 함수
 * @param {number} index select element's index
 * @param keyList select option list
 */
const getTestKeySelect = (index, keyList) => {
    const testKeySelect = document.createElement("select");
    testKeySelect.id = `test-key-select-${index}`;
    const placeholderOption = document.createElement("option");
    placeholderOption.text = "Key 선택";
    placeholderOption.selected = true;
    placeholderOption.disabled = true;
    testKeySelect.add(placeholderOption);
    keyList.forEach((testKey) => {
        const option = document.createElement("option");
        option.text = testKey.common_part_nm;
        option.value = testKey.common_part_cd;
        testKeySelect.add(option);
    });
    testKeySelect.addEventListener("change", (event) =>
        handleChangeTestKey(event, index)
    );
    return testKeySelect;
};

/**
 * @description 추출 영역 검증 핸들러
 * @param {Event} event onclick event
 * @param {number} index target index
 */
const handleVerifyExtract = async (event, index) => {
    if (extractData[currentPageIndex][index]) {
        showLoading();
        console.log(extractData[currentPageIndex][index]);

        const { areaType, areaX, areaY, areaWidth, areaHeight } =
            extractData[currentPageIndex][index];
        const result = await fetch(
            `${VERIFY_PARSER_AREA}?templateId=${templateId}&areaType=${areaType}&areaX=${areaX}&areaY=${areaY}&areaWidth=${areaWidth}&areaHeight=${areaHeight}&page=${currentPageIndex + 1
            }`
        )
            .then((response) => response.json())
            .then((data) => {
                return data;
            })
            .catch((error) => console.log("error:", error));

        if (result) {
            console.log(result);
            const { Code, Data, Message } = result;
            if (Code === "SUCCESS") {
                console.log("Verified Data:", Data);

                const $title = document.querySelector("#verify-result h5");
                if (areaType === "TEXT") {
                    $title.innerText = "텍스트 추출 결과";
                    console.log($resultContainer);
                    $resultContainer.classList.remove("image-container");
                    $resultContainer.classList.add("text-container");
                    $resultContainer.innerText = Data;
                }
                if (areaType === "IMAGE") {
                    $title.innerText = "이미지 추출 결과";
                    const resultImage = document.createElement("img");
                    resultImage.setAttribute("width", "100%");
                    resultImage.src = "data:image/png;base64," + Data;
                    $resultContainer.classList.remove("text-container");
                    $resultContainer.classList.add("image-container");
                    $resultContainer.innerHTML = "";
                    $resultContainer.appendChild(resultImage);
                }
                hideLoading();
                showVerifyResult();
            }
        }
        hideLoading();
    }
};

/**
 * @description 추출 영역 삭제 이벤트 핸들러
 * @param {Event} event onclick event
 * @param {number} index target index
 */
const handleRemoveExtract = (event, index) => {
    initExractRect();
    const $targetElement = document.getElementById(`extract-wrapper-${index}`);
    $extractList.removeChild($targetElement);
    extractData[currentPageIndex].splice(index, 1);
    coordinateList[currentPageIndex].splice(index, 1);
};

/**
 * @description 추출 영역 선택 버튼 ON 핸들러
 * @param {number} index target index
 */
const handleToggleButtonOn = (index) => {
    const toggleExtractButton = document.getElementById(
        `toggle-extract-button-${index}`
    );

    const $allToggleButtons = document.querySelectorAll(".toggle-button");
    $allToggleButtons.forEach((element) => {
        element.classList.remove("on");
        element.classList.add("off");
    });
    toggleExtractButton.classList.remove("off");
    toggleExtractButton.classList.add("on");
};

/**
 * @description 추출 영역 선택 시작 함수
 * @param {'TEXT' | 'IMAGE'} extractType extract type
 * @param {number} index target index
 */
const handleStartExtract = (extractType, index) => {
    targetExtractType = extractType;
    targetExtractIndex = index;

    coordinateList[currentPageIndex][index] = {
        startX: 0,
        startY: 0,
        endX: 0,
        endY: 0,
    };

    initExractRect();
    renderExtractRect(extractType, index);
    handleToggleButtonOn(index);
};

/**
 * @description 텍스트 추출 영역 추가 이벤트 핸들러
 * @param {number|null} passedIndex 기존에 지정된 정보 로딩을 위한 인덱스
 */
const handleAddTextExtract = (passedIndex) => {
    const index =
        passedIndex !== null ? passedIndex : extractData[currentPageIndex].length;
    const testKeySelect = getTestKeySelect(index, testKeyList); // Test Key Select박스

    const valueExtractInput = document.createElement("input");
    valueExtractInput.id = `value-extract-input-${index}`;
    valueExtractInput.type = "text";
    valueExtractInput.placeholder = "Value 영역 선택";
    valueExtractInput.readOnly = true;
    valueExtractInput.addEventListener("click", (event) => {
        initExractRect();
        renderExtractRect("TEXT", index);
    });

    const toggleIcon = document.createElement("span");
    toggleIcon.classList.add("material-icons", "toggle-icon");
    // toggleIcon.innerText = "highlight_alt";

    const toggleExtractButton = document.createElement("button");
    toggleExtractButton.id = `toggle-extract-button-${index}`;
    toggleExtractButton.dataset.tooltip = "텍스트 추출 영역 선택";
    toggleExtractButton.type = "button";
    toggleExtractButton.appendChild(toggleIcon);
    toggleExtractButton.classList.add(
        "toggle-button",
        "text-toggle-button",
        "off"
    );
    toggleExtractButton.addEventListener("click", (event) => {
        if (toggleExtractButton.classList.contains("off")) {
            handleStartExtract("TEXT", index);
        } else {
            toggleExtractButton.classList.remove("on");
            toggleExtractButton.classList.add("off");
            initExractRect();
        }
    });

    const valueExtractContainer = document.createElement("div");
    valueExtractContainer.id = `value-extract-container-${index}`;
    valueExtractContainer.classList.add("row", "value-extract-container");
    valueExtractContainer.appendChild(valueExtractInput);
    valueExtractContainer.appendChild(toggleExtractButton);

    const removeIcon = document.createElement("span");
    removeIcon.classList.add("material-icons-outlined", "remove-icon");
    const removeButton = document.createElement("button");
    removeButton.dataset.tooltip = "텍스트 추출 영역 삭제";
    removeButton.type = "button";
    removeButton.appendChild(removeIcon);
    removeButton.addEventListener("click", (event) =>
        handleRemoveExtract(event, index)
    );

    const checkIcon = document.createElement("span");
    checkIcon.classList.add("material-icons-outlined", "check-icon");
    const verfiyButton = document.createElement("button");
    verfiyButton.dataset.tooltip = "텍스트 추출 영역 자료 확인";
    verfiyButton.type = "button";
    verfiyButton.appendChild(checkIcon);
    verfiyButton.addEventListener("click", (event) => {
        initExractRect();
        renderExtractRect("TEXT", index);
        handleVerifyExtract(event, index);
    });

    const textExtractContainer = document.createElement("div");
    textExtractContainer.id = `text-extract-container-${index}`;
    textExtractContainer.classList.add("row", "text-extract-container", "gap-8");
    textExtractContainer.appendChild(testKeySelect);
    textExtractContainer.appendChild(valueExtractContainer);
    textExtractContainer.appendChild(verfiyButton);
    textExtractContainer.appendChild(removeButton);
    textExtractContainer.addEventListener("click", (event) => {
        const rectButton = document.getElementById(`toggle-extract-button-${index}`);
        if (rectButton.classList.contains('off')) {
            rectButton.click();
        }
    });


    const helperTextContainer = document.createElement("div");
    helperTextContainer.id = `helper-text-container-${index}`;

    const extractWrapper = document.createElement("div");
    extractWrapper.id = `extract-wrapper-${index}`;
    extractWrapper.classList.add("column", "extract-wrapper", "gap-4");
    extractWrapper.appendChild(textExtractContainer);
    extractWrapper.appendChild(helperTextContainer);

    $extractList.appendChild(extractWrapper);
    if (passedIndex === null) {
        extractData[currentPageIndex][index] = {
            areaType: "TEXT",
        };
    }
    // handleStartExtract("TEXT", index);
};

/**
 * @description 이미지 추출 영역 추가 이벤트 핸들러
 * @param {number|null} passedIndex 기존에 지정된 정보 로딩을 위한 인덱스
 */
const handleAddImageExtract = (passedIndex) => {
    const index =
        passedIndex !== null ? passedIndex : extractData[currentPageIndex].length;
    const testKeySelect = getTestKeySelect(index, testImageKeyList); // Test Key Select박스

    const valueExtractInput = document.createElement("input");
    valueExtractInput.id = `value-extract-input-${index}`;
    valueExtractInput.type = "text";
    valueExtractInput.placeholder = "이미지 영역 선택";
    valueExtractInput.readOnly = true;
    valueExtractInput.addEventListener("click", (event) => {
        initExractRect();
        renderExtractRect("IMAGE", index);
    });

    const toggleIcon = document.createElement("span");
    toggleIcon.classList.add("material-icons", "toggle-icon");

    const toggleExtractButton = document.createElement("button");
    toggleExtractButton.id = `toggle-extract-button-${index}`;
    toggleExtractButton.dataset.tooltip = "이미지 추출 영역 선택";
    toggleExtractButton.type = "button";
    toggleExtractButton.appendChild(toggleIcon);
    toggleExtractButton.classList.add(
        "toggle-button",
        "image-toggle-button",
        "off"
    );
    toggleExtractButton.addEventListener("click", (event) => {
        if (toggleExtractButton.classList.contains("off")) {
            handleStartExtract("IMAGE", index);
        } else {
            toggleExtractButton.classList.remove("on");
            toggleExtractButton.classList.add("off");

            initExractRect();
        }
    });

    const valueExtractContainer = document.createElement("div");
    valueExtractContainer.id = `value-extract-container-${index}`;
    valueExtractContainer.classList.add("row", "value-extract-container");
    valueExtractContainer.appendChild(valueExtractInput);
    valueExtractContainer.appendChild(toggleExtractButton);

    const removeIcon = document.createElement("span");
    removeIcon.classList.add("material-icons-outlined", "remove-icon");
    const removeButton = document.createElement("button");
    removeButton.dataset.tooltip = "이미지 추출 영역 삭제";
    removeButton.type = "button";
    removeButton.appendChild(removeIcon);
    removeButton.addEventListener("click", (event) =>
        handleRemoveExtract(event, index)
    );

    const checkIcon = document.createElement("span");
    checkIcon.classList.add("material-icons-outlined", "check-icon");
    const verfiyButton = document.createElement("button");
    verfiyButton.dataset.tooltip = "이미지 추출 영역 자료 확인";
    verfiyButton.type = "button";
    verfiyButton.appendChild(checkIcon);
    verfiyButton.addEventListener("click", (event) => {
        initExractRect();
        renderExtractRect("IMAGE", index);
        handleVerifyExtract(event, index);
    });

    const imageExtractContainer = document.createElement("div");
    imageExtractContainer.id = `image-extract-container-${index}`;
    imageExtractContainer.classList.add(
        "row",
        "image-extract-container",
        "gap-8"
    );
    imageExtractContainer.appendChild(testKeySelect);
    imageExtractContainer.appendChild(valueExtractContainer);
    imageExtractContainer.appendChild(verfiyButton);
    imageExtractContainer.appendChild(removeButton);
    imageExtractContainer.addEventListener("click", (event) => {
        const rectButton = document.getElementById(`toggle-extract-button-${index}`);
        if (rectButton.classList.contains('off')) {
            rectButton.click();
        }
    });

    const helperTextContainer = document.createElement("div");
    helperTextContainer.id = `helper-text-container-${index}`;

    const extractWrapper = document.createElement("div");
    extractWrapper.id = `extract-wrapper-${index}`;
    extractWrapper.classList.add("column", "extract-wrapper", "gap-4");
    extractWrapper.appendChild(imageExtractContainer);
    extractWrapper.appendChild(helperTextContainer);

    $extractList.appendChild(extractWrapper);
    if (passedIndex === null) {
        extractData[currentPageIndex][index] = {
            areaType: "IMAGE",
        };
    }

    // handleStartExtract("IMAGE", index);
};

/**
 * @description 추출 결과 창 열기 이벤트 핸들러
 * @param {Event} event onclick event
 */
const showVerifyResult = (event) => {
    $verifyResult.style.display = "flex";
};

/**
 * @description 추출 결과 창 닫기 이벤트 핸들러
 * @param {Event} event onclick event
 */
const hideVerifyResult = (event) => {
    $verifyResult.style.display = "none";
    $resultContainer.innerHTML = "";
};

/**
 * @description 템플릿 영역 추출 정보 저장 이벤트 핸들러
 * @param {Event} event onclick event
 */
const handleSave = async (event) => {
    showLoading();
    if (extractData.length > 0) {
        const pageList = extractData.map((extractItem, index) => {
            if (extractItem && extractItem.length > 0) {
                return {
                    page: index + 1,
                    parserAreaList: extractItem,
                };
            }
        });
        const data = {
            templateId,
            pageList,
        };

        console.log("input Data:", data);
        const result = await fetch(POST_PARSER_AREA_CONFIG, {
            method: "post",
            body: JSON.stringify(data),
        })
            .then((response) => response.json())
            .then((data) => {
                return data;
            })
            .catch((error) => console.log("error:", error));
        console.log(result);
        if (result) {
            const { Code } = result;
            if (Code === "SUCCESS") {
                // alert(
                //   "템플릿 영역 설정 정보 저장이 완료되었습니다\n미리보기 화면으로 이동합니다"
                // );
                // moveToParserResult(templateId, uploadId);
                alert(
                    "템플릿 영역 설정 정보 저장이 완료되었습니다\n홈 화면으로 되돌아갑니다"
                );
                moveToHome();
            } else {
                alert("템플릿 영역 설정 정보 저장에 실패했습니다\n다시 시도해주세요");
            }
        }
    } else {
        alert(
            "템플릿 영역 설정 정보가 존재하지 않습니다\n영역 정보 설정 후 다시 시도해주세요"
        );
    }

    hideLoading();
};

(function () {
    const passedTemplateId = getParameter("templateId");
    const passedUploadId = getParameter("uploadId");
    if (passedTemplateId) {
        templateId = passedTemplateId;
        uploadId = passedUploadId;
        loadParserResult(templateId, uploadId);
        loadTestKeyList();
        loadTestImageKeyList();
    } else {
        alert("상세설정 변경 화면에는 템플릿 ID와 업로드 ID가 필요합니다");
        moveToSettings();
    }
    $extractList = document.getElementById("extract-list");
    $verifyResult = document.getElementById("verify-result");
    $resultContainer = document.querySelector(
        "#verify-result .verify-result-container"
    );
    $currentPage = document.getElementById("current-page");
    $previousButton = document.getElementById("previous-button");
    $nextButton = document.getElementById("next-button");
})();
window.onload = function () {
    // 텍스트 추출 추가 버튼 클릭 이벤트 등록
    document
        .getElementById("add-text-extract-button")
        .addEventListener("click", (event) => handleAddTextExtract(null));

    // 이미지 추출 추가 버튼 클릭 이벤트 등록
    document
        .getElementById("add-image-extract-button")
        .addEventListener("click", (event) => handleAddImageExtract(null));

    // 추출 영역 정보 저장 버튼 클릭 이벤트 등록
    document.getElementById("save-button").addEventListener("click", handleSave);

    // 추출 검증창 닫기 버튼 클릭 이벤트 등록
    document
        .querySelector("#verify-result .close")
        .addEventListener("click", hideVerifyResult);

    // 추출 영역 클릭 이벤트 등록
    document
        .getElementById("extract-container")
        .addEventListener("click", (event) => hideVerifyResult());

    // PDF 영역 클릭 이벤트 등록
    document
        .getElementById("pdf-container")
        .addEventListener("click", (event) => hideVerifyResult());

    // PDF 확대 버튼 클릭 이벤트 등록
    document
        .getElementById("zoom-in-button")
        .addEventListener("click", (event) => handleZoomIn());

    // PDF 축소 버튼 클릭 이벤트 등록
    document
        .getElementById("zoom-out-button")
        .addEventListener("click", (event) => handleZoomOut());

    // PDF 이전 페이지 이동 버튼 클릭 이벤트 등록
    $previousButton.addEventListener("click", (event) => moveToPrevious());

    // PDF 다음 페이지 이동 버튼 클릭 이벤트 등록
    $nextButton.addEventListener("click", (event) => moveToNext());

    initTooltipEvent();
};
