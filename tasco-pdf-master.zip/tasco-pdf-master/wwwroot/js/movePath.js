export const moveToHome = () => {
    window.location.href = `/`;
};

export const moveToSettings = () => {
    window.location.href = `/Parser/ParserConfig`;
};

export const moveToSettingsDetail = (templateId) => {
    window.location.href = `/Parser/PdfArea?templateId=${templateId}`;
};

export const moveToParser = () => {
    window.location.href = `/Parser/ParserInfo`;
};

export const moveToParserResult = (templateId, uploadId) => {
    window.location.href = `/Parser/ParserResult?templateId=${templateId}&uploadId=${uploadId}`;
};

export const moveToTemplateEdit = (templateId, uploadId) => {
    window.location.href = `/Parser/PdfAreaEdit?templateId=${templateId}&uploadId=${uploadId}`;
};