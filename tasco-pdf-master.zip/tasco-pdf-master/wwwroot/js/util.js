/**
 * @description 파라미터값 리턴 함수
 * @param {string} param parameter name
 * @returns
 */
export const getParameter = (param) => {
  param = param.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  var regex = new RegExp("[\\?&]" + param + "=([^&#]*)"),
    results = regex.exec(location.search);
  return results === null
    ? ""
    : decodeURIComponent(results[1].replace(/\+/g, " "));
};
