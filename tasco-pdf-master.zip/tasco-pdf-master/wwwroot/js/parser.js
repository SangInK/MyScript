import { GET_TEMPLATE_LIST, POST_PARSER_PDF_UPLOAD } from "./api.js";
import { showLoading, hideLoading } from "./loading.js";
import { moveToParserResult } from "./movePath.js";

let $templateSelect;
let $submit;
let $pdfUploadInput;
let $pdfFile;

let uploadedReport; // 업로드된 시험 분석서 파일
let templateList; // 템플릿 목록
let selectedTemplateIndex; // 선택된 템플릿 인덱스
let selectedTemplateId; // 선택된 템플릿

/**
 * @description 템플릿 목록 로딩 함수
 * @param {Event} event onchange event
 */
const loadTemplateList = async () => {
  showLoading();
  const result = await fetch(GET_TEMPLATE_LIST)
    .then((response) => response.json())
    .then((data) => {
      return data;
    })
    .catch((error) => console.log("error:", error));

  if (result) {
    console.log("Template List:", result);
    const { Code, Data } = result;
    if (Code === "SUCCESS") {
      templateList = Data;
      templateList.forEach((template, index) => {
        const { TesterKrName, TestItemKrName, TestTypeKrName } = template;
        const option = document.createElement("option");
        option.text = `${TesterKrName} / ${TestItemKrName} / ${TestTypeKrName}`;
        option.value = index;
        $templateSelect.add(option);
      });
    }
  }
  hideLoading();
};

/**
 * @description 시험분석서 전송 전 유효성 검사 함수
 * @param {Event} event onchange event
 */
const validateFields = () => {
  if (!selectedTemplateId) {
    $submit.disabled = true;
    return;
  }
  if (!("File" in window && uploadedReport instanceof File)) {
    $submit.disabled = true;
    return;
  }
  $submit.disabled = false;
};

/**
 * @description 템플릿 목록 변경 이벤트 핸들러
 * @param {Event} event onchange event
 */
const handleChangeTemplate = (event) => {
  console.log("template selected", event.target.value);
  selectedTemplateIndex = event.target.value;
  const { TemplateId, Tester, TestItem, TestType } =
    templateList[selectedTemplateIndex];
  selectedTemplateId = TemplateId;
  validateFields();
};

/**
 * @description 시험 분석서 파일 업로드 이벤트 핸들러
 * @param {Event} event file upload event
 */
const handleUploadReport = (event) => {
  uploadedReport = event.target.files[0];
  $pdfUploadInput.value = uploadedReport.name;
  validateFields();
  console.log("pdf uploaded", uploadedReport);
};

/**
 * @description 시험분석서 전송 핸들러
 * @param {Event} event onclick event
 */
const handleSubmit = async (event) => {
  showLoading();
  const data = new FormData();
  data.append("file", uploadedReport);
  const result = await fetch(POST_PARSER_PDF_UPLOAD, {
    method: "post",
    body: data,
  })
    .then((response) => response.json())
    .then((data) => {
      return data;
    })
    .catch((error) => console.log("error:", error));
  hideLoading();
  if (result) {
    //TODO: 만약 안되면 이부분을 봐주세요~
    console.log(result);
    const { Code, Data } = result;
    if (Code === "SUCCESS") {
      const { UploadId } = Data;
      moveToParserResult(selectedTemplateId, UploadId);
    } else {
      alert("시험 분석서 전송에 실패했습니다\n다시 시도해주세요");
    }
  }
};

(function () {
  $submit = document.getElementById("submit");
  $pdfUploadInput = document.getElementById("pdf-upload-input");
  $pdfFile = document.getElementById("pdf-file");
  $templateSelect = document.getElementById("template-select");
  loadTemplateList();
})();

window.onload = function () {
  $templateSelect.addEventListener("change", handleChangeTemplate);
  $pdfFile.addEventListener("change", handleUploadReport);

  $submit.addEventListener("click", handleSubmit);
};
