import { BASE_URL, GET_PARSER_PROCESS } from "./api.js";
import { showLoading, hideLoading } from "./loading.js";
import { moveToParser, moveToTemplateEdit } from "./movePath.js";
import { getParameter } from "./util.js";

let loadedPdf; // 로딩된 PDF
let totalPage = -1; // PDF 전체 페이지수
let currentPageIndex = -1; // PDF 현재 페이지 인덱스
let scaleUnit = 1.8; // PDF의 화면 스케일 비율

let $coordinateCanvas;
let $coordinateContext;
let $resultWrapper;
let $currentPage;
let $previousButton;
let $nextButton;

let templateId; // 로딩된 템플릿 ID
let uploadId; // 로딩된 업로드 ID
let pdfPath; // 업로드된 PDF 경로
let pdfWidth; // PDF 가로길이 from Server
let pdfHeight; // PDF 세로길이 from Server

const extractData = [[]]; // 추출 영역 데이터 리스트

/**
 * @description Parser Area 렌러딩 함수
 */
const renderParserArea = () => {
  if (
    extractData.length > 0 &&
    extractData[currentPageIndex] &&
    extractData[currentPageIndex].length > 0
  ) {
    extractData[currentPageIndex].forEach((areaItem) => {
      const { areaX, areaY, areaWidth, areaHeight, areaType } = areaItem;
      $coordinateContext.strokeStyle =
        areaType === "TEXT" ? "#f44336" : "#4caf50";
      const canvasWidth = $coordinateCanvas.width;
      const canvasHeight = $coordinateCanvas.height;
      $coordinateContext.strokeRect(
        (areaX * canvasWidth) / pdfWidth,
        (areaY * canvasHeight) / pdfHeight,
        (areaWidth * canvasWidth) / pdfWidth,
        (areaHeight * canvasHeight) / pdfHeight
      );
    });
  }
};

/**
 * @description 이전 페이지 이동 가능 여부 판별
 */
const checkMovablePage = () => {
  if (currentPageIndex > 0) {
    $previousButton.disabled = false;
  } else {
    $previousButton.disabled = true;
  }

  if (currentPageIndex < totalPage - 1) {
    $nextButton.disabled = false;
  } else {
    $nextButton.disabled = true;
  }
};

/**
 * @description PDF 이전 페이지 이동
 */
const moveToPrevious = () => {
  // scaleUnit = 1.8;
  const previousPage = currentPageIndex - 1;
  if (previousPage > -1) {
    currentPageIndex = previousPage;
    checkMovablePage();
    renderPage(currentPageIndex);
    // loadExtractData();
  }
};

/**
 * @description PDF 다음 페이지 이동
 */
const moveToNext = () => {
  // scaleUnit = 1.8;
  const nextPage = currentPageIndex + 1;
  if (nextPage < totalPage) {
    currentPageIndex = nextPage;
    checkMovablePage();
    renderPage(currentPageIndex);
    // loadExtractData();
  }
};

/**
 * @description PDF 화면 확대 이벤트 핸들리
 */
const handleZoomIn = () => {
  scaleUnit += 0.25;
  renderPage(currentPageIndex);
};

/**
 * @description PDF 화면 축소 이벤트 핸들리
 */
const handleZoomOut = () => {
  scaleUnit -= 0.25;
  renderPage(currentPageIndex);
};

/**
 * @description PDF Page 렌더링 함수
 * @param {number} pageIndex PDF page index
 */
const renderPage = async (pageIndex) => {
  $currentPage.innerText = pageIndex + 1;
  const page = await loadedPdf.getPage(pageIndex + 1);

  const pdfCanvas = document.createElement("canvas");
  pdfCanvas.className = "pdf";
  pdfCanvas.id = "pdf-canvas";

  const pdfWrapper = document.createElement("div");
  pdfWrapper.className = "pdf-wrapper";
  pdfWrapper.id = "pdf-wrapper";
  pdfWrapper.appendChild(pdfCanvas);

  const pdfArea = document.getElementById("pdf-container");

  pdfArea.replaceChildren(pdfWrapper);

  const pdfContext = pdfCanvas.getContext("2d");

  const scale = scaleUnit;

  const viewport = page.getViewport({ scale });
  pdfCanvas.height = viewport.height;
  pdfCanvas.width = viewport.width;

  const renderContext = {
    canvasContext: pdfContext,
    viewport: viewport,
  };

  const renderTask = page.render(renderContext);
  renderTask.promise.then(function () {
    console.log("Page rendered");

    pdfWrapper.addEventListener("wheel", (event) => {
      if (event.ctrlKey) {
        event.preventDefault();

        if (event.deltaY < 0) {
          handleZoomIn();
        } else if (event.deltaY > 0) {
          handleZoomOut();
        }
      }
    });

    const coordinateContainer = document.createElement("div");
    coordinateContainer.className = "coordinate-container";
    coordinateContainer.id = `coordinate-container`;
    const coordinateCanvas = document.createElement("canvas");
    coordinateCanvas.id = "coordinate-canvas";
    coordinateCanvas.height = viewport.height;
    coordinateCanvas.width = viewport.width;

    coordinateContainer.appendChild(coordinateCanvas);
    pdfWrapper.appendChild(coordinateContainer);
    $coordinateCanvas = coordinateCanvas;
    $coordinateContext = coordinateCanvas.getContext("2d");
    $coordinateContext.lineWidth = 1;

    renderParserArea();
  });
};

/**
 * @description PDF 파일 로드 및 초기 세팅 함수
 */
const loadPdf = () => {
  showLoading();
  const loadingTask = pdfjsLib.getDocument(pdfPath);
  pdfjsLib.workerSrc = "/js/pdfjs-3.2.146/pdf.worker.js";
  loadingTask.promise.then(function (pdf) {
    console.log("PDF loaded");
    console.log(pdf);

    totalPage = pdf.numPages;
    console.log("Total Page: ", totalPage);
    document.getElementById("total-page").innerText = totalPage;

    loadedPdf = pdf;
    currentPageIndex = 0;
    renderPage(currentPageIndex);
  });
  hideLoading();
};

/**
 * @description 시험 보고서 파싱 결과 불러오기 함수
 * @param {string} templateId 템플릿 ID
 * @param {string} uploadId 업로드 ID
 */
const loadParserResult = async (templateId, uploadId) => {
  showLoading();
  const result = await fetch(
    `${GET_PARSER_PROCESS}?templateId=${templateId}&uploadId=${uploadId}`
  )
    .then((response) => response.json())
    .then((data) => {
      return data;
    })
    .catch((error) => console.log("error:", error));
  console.log(result);
  if (result) {
    const { Code, Data } = result;
    if (Code === "SUCCESS") {
      const {
        OrgFilename,
        Width,
        Height,
        Tester,
        TesterKrName,
        TestItem,
        TestItemKrName,
        TestType,
        TestTypeKrName,
        WebPath,
        PdfList,
      } = Data;
      pdfPath = `${BASE_URL}${WebPath}`;
      pdfWidth = Width;
      pdfHeight = Height;
      document.getElementById("pdf-file-name").innerText = OrgFilename;
      document.getElementById(
        "pdf-info"
      ).innerText = `${TesterKrName}/${TestItemKrName}/${TestTypeKrName}`;

      const textResultContainer = document.createElement("div");
      const imageResultContainer = document.createElement("div");

      const textResultTable = document.createElement("table");
      const textResultThead = document.createElement("thead");
      const textResultTbody = document.createElement("tbody");
      const theadRow = document.createElement("tr");
      const theadColumn0 = document.createElement("th");
      theadColumn0.innerText = "텍스트 Key";
      theadRow.appendChild(theadColumn0);
      const theadColumn1 = document.createElement("th");
      theadColumn1.innerText = "추출 값";
      theadRow.appendChild(theadColumn1);
      textResultThead.appendChild(theadRow);
      textResultTable.appendChild(textResultThead);

      loadPdf(); // PDF 표시

      // PDF List 조회를 통한 결과값 생성
        if (PdfList === null || PdfList.length == 0) {
          alert("자료 추출 영역이 없습니다.");
        }
        else {
        PdfList.forEach((pdfItem) => {
          const { Page, PdfAreaList } = pdfItem;
          if (PdfAreaList && PdfAreaList.length > 0) {
            const pageIndex = Page - 1;
            if (
              extractData[pageIndex] === undefined ||
              !extractData[pageIndex]
            ) {
              extractData[pageIndex] = [];
            }

            PdfAreaList.forEach((item) => {
              const {
                TemplateId,
                TemplateAreaId,
                AreaOrder,
                common_part_nm,
                TestKey,
                AreaType,
                AreaX,
                AreaY,
                AreaWidth,
                AreaHeight,
                AreaData,
              } = item;

              if (AreaType === "TEXT") {
                const textResultRow = document.createElement("tr");
                const textResultKey = document.createElement("td");
                textResultKey.innerText = common_part_nm;
                textResultRow.appendChild(textResultKey);
                const textResultValue = document.createElement("td");
                textResultValue.innerText = AreaData;
                textResultRow.appendChild(textResultValue);
                textResultTbody.appendChild(textResultRow);
              } else if (AreaType === "IMAGE") {
                const imageResultWrapper = document.createElement("div");
                imageResultWrapper.classList.add(
                  "image-result-wrapper",
                  "column",
                  "gap-4"
                );
                const label = document.createElement("label");
                label.innerText = common_part_nm;
                imageResultWrapper.appendChild(label);
                const image = document.createElement("img");
                image.setAttribute("width", "100%");
                image.src = "data:image/png;base64," + AreaData;
                const imageWrapper = document.createElement("div");
                imageWrapper.classList.add("image-wrapper");
                imageWrapper.appendChild(image);
                imageResultWrapper.appendChild(imageWrapper);
                // imageResultWrapper.appendChild(image);
                imageResultContainer.appendChild(imageResultWrapper);
              }

              extractData[pageIndex].push({
                templateId: TemplateId,
                testKey: TestKey,
                areaType: AreaType,
                areaX: AreaX,
                areaY: AreaY,
                areaWidth: AreaWidth,
                areaHeight: AreaHeight,
              });
            });
          }

          textResultTable.appendChild(textResultTbody);

          textResultContainer.appendChild(textResultTable);
          $resultWrapper.appendChild(textResultContainer);
          $resultWrapper.appendChild(imageResultContainer);          
        });
      }
    }
  }
  hideLoading();
};

(function () {
  const passedTemplateId = getParameter("templateId");
  const passedUploadId = getParameter("uploadId");
  if (passedTemplateId && passedUploadId) {
    templateId = passedTemplateId;
    uploadId = passedUploadId;
    loadParserResult(templateId, uploadId);
  } else {
    alert("상세설정 화면에는 템플릿 ID와 업로드 ID가 필요합니다");
    moveToParser();
  }

  $resultWrapper = document.getElementById("result-wrapper");
  $currentPage = document.getElementById("current-page");
  $previousButton = document.getElementById("previous-button");
  $nextButton = document.getElementById("next-button");
})();
window.onload = function () {
  // PDF 확대 버튼 클릭 이벤트 등록
  document
    .getElementById("zoom-in-button")
    .addEventListener("click", (event) => handleZoomIn());

  // PDF 이전 페이지 이동 버튼 클릭 이벤트 등록
  $previousButton.addEventListener("click", (event) => moveToPrevious());

  // PDF 다음 페이지 이동 버튼 클릭 이벤트 등록
  $nextButton.addEventListener("click", (event) => moveToNext());

  // PDF 축소 버튼 클릭 이벤트 등록
  document
    .getElementById("zoom-out-button")
    .addEventListener("click", (event) => handleZoomOut());

  // document
  //   .getElementById("edit-template-button")
  // .addEventListener("click", (event) => moveToTemplateEdit(templateId));
};
