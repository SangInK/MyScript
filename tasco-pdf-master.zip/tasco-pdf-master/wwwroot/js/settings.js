import {
    GET_TEMPLATE_LIST,
    GET_TESTER_LIST,
    GET_TEST_ITEM_LIST,
    GET_TEST_TYPE_LIST,
    POST_PARSER_CONFIG,
    POST_PARSER_CONFIG_UPDATE,
    DELETE_PARSER_CONFIG,
} from "./api.js";
import { showLoading, hideLoading } from "./loading.js";
import { moveToSettingsDetail, moveToTemplateEdit } from "./movePath.js";

let $templateSelect;
let $addTemplate;
let $editTemplate;
let $removeTemplate;
let $templateUploadInput;
let $templateFile;
let $testerSelect;
let $testItemSelect;
let $testTypeSelect;

let templateList; // 저장된 템플릿 목록
let selectedTemplateIndex = -1; // 선택된 템플릿 인덱스
let selectedTemplateId; // 선택된 템플릿
let uploadedTemplate; // 업로드된 템플릿 파일

let testerList; // 시험 기기 목록
let testItemList; // 시험 종류 목록
let testTypeList; // 시험 구분 목록

let selectedTester; // 선택된 시험 기기
let selectedTestItem; // 선택된 시험 종류
let selectedTestType; // 선택된 시험 구분

/**
 * @description 템플릿 목록 불러오기
 */
const getTemplateList = async () => {
    showLoading();
    const result = await fetch(GET_TEMPLATE_LIST)
        .then((response) => response.json())
        .then((data) => data)
        .catch((error) => console.log("error:", error));

    console.log("Template List:", result);
    const { Code, Data } = result;
    $templateSelect.innerHTML = "";
    const option = document.createElement("option");
    option.selected = true;
    option.disabled = true;
    option.text = "템플릿 선택";
    $templateSelect.add(option);
    if (Code === "SUCCESS") {
        templateList = Data;

        templateList.forEach((template, index) => {
            const { TesterKrName, TestItemKrName, TestTypeKrName } = template;
            const option = document.createElement("option");
            option.name = "template-option";
            option.text = `${TesterKrName} / ${TestItemKrName} / ${TestTypeKrName}`;
            option.value = index;
            $templateSelect.add(option);
        });
    }
    hideLoading();
};

/**
 * @description 시험 기기 목록 불러오기
 */
const getTesterList = async () => {
    showLoading();
    const result = await fetch(GET_TESTER_LIST)
        .then((response) => response.json())
        .then((data) => data)
        .catch((error) => console.log("error:", error));
    console.log("Tester List: ", result);
    testerList = result;
    $testerSelect.innerHTML = "";
    const option = document.createElement("option");
    option.selected = true;
    option.disabled = true;
    option.value = "";
    option.text = "시험 기기";
    $testerSelect.add(option);

    if (testerList && testerList.length > 0) {
        testerList.forEach((tester) => {
            const option = document.createElement("option");
            option.text = tester.tester_nm;
            option.value = tester.tester_cd;
            $testerSelect.add(option);
        });
    }
    hideLoading();
};

/**
 * @description 시험 종류 목록 불러오기
 */
const getTestItemList = async () => {
    showLoading();
    const result = await fetch(GET_TEST_ITEM_LIST)
        .then((response) => response.json())
        .then((data) => data)
        .catch((error) => console.log("error:", error));
    console.log("Test Item List: ", result);
    testItemList = result;
    $testItemSelect.innerHTML = "";
    const option = document.createElement("option");
    option.selected = true;
    option.disabled = true;
    option.value = "";
    option.text = "시험 종류";
    $testItemSelect.add(option);

    if (testItemList && testItemList.length > 0) {
        testItemList.forEach((testItem) => {
            const option = document.createElement("option");
            option.text = testItem.testitem_nm;
            option.value = testItem.testitem_cd;
            $testItemSelect.add(option);
        });
    }
    hideLoading();
};

/**
 * @description 시험 구분 목록 불러오기
 */
const getTestTypeList = async () => {
    showLoading();
    const result = await fetch(GET_TEST_TYPE_LIST)
        .then((response) => response.json())
        .then((data) => data)
        .catch((error) => console.log("error:", error));
    console.log("Test Type List: ", result);
    testTypeList = result;
    $testTypeSelect.innerHTML = "";
    const option = document.createElement("option");
    option.selected = true;
    option.disabled = true;
    option.value = "";
    option.text = "시험 구분";
    $testTypeSelect.add(option);

    if (testTypeList && testTypeList.length > 0) {
        testTypeList.forEach((testType) => {
            const option = document.createElement("option");
            option.text = testType.common_part_nm;
            option.value = testType.common_part_cd;
            $testTypeSelect.add(option);
        });
    }
    hideLoading();
};

/**
 * @description 템플릿 등록 전 유효성 검사 함수
 * @param {Event} event onchange event
 */
const validateAddTemplate = () => {
    if (typeof selectedTester !== "string") {
        $addTemplate.disabled = true;
        return;
    }
    if (typeof selectedTestItem !== "string") {
        $addTemplate.disabled = true;
        return;
    }
    if (typeof selectedTestType !== "string") {
        $addTemplate.disabled = true;
        return;
    }
    console.log(uploadedTemplate);
    if (!("File" in window && uploadedTemplate instanceof File)) {
        $addTemplate.disabled = true;
        return;
    }
    $addTemplate.disabled = false;
};

/**
 * @description 기존 설정된 템플릿 목록 변경 이벤트 핸들러
 * @param {Event} event onchange event
 */
const handleChangeTemplate = (event) => {
    selectedTemplateIndex = event.target.value;

    console.log("Selected Template: ", templateList[selectedTemplateIndex]);
    const { TemplateId, Tester, TestItem, TestType, OrgFilename } =
        templateList[selectedTemplateIndex];
    selectedTemplateId = TemplateId;
    $testerSelect.value = Tester;
    selectedTester = Tester;
    $testItemSelect.value = TestItem;
    selectedTestItem = TestItem;
    $testTypeSelect.value = TestType;
    selectedTestType = TestType;
    $templateUploadInput.value = OrgFilename;
    $editTemplate.disabled = false;
    $removeTemplate.disabled = false;
};

/**
 * @description 템플릿 파일 업로드 이벤트 핸들러
 * @param {Event} event file upload event
 */
const handleUploadTemplate = (event) => {
    uploadedTemplate = event.target.files[0];
    $templateUploadInput.value = uploadedTemplate.name;
    validateAddTemplate();
    console.log("template uploaded", uploadedTemplate);
};

/**
 * @description 시험 기기 변경 이벤트 핸들러
 * @param {Event} event onchange event
 */
const handleChangeTester = (event) => {
    selectedTester = event.target.value;
    validateAddTemplate();
    console.log("tester changed", event.target.value);
};

/**
 * @description 시험 종류  변경 이벤트 핸들러
 * @param {Event} event onchange event
 */
const handleChangeTestItem = (event) => {
    selectedTestItem = event.target.value;
    validateAddTemplate();
    console.log("test item changed", event.target.value);
};

/**
 * @description 시험 구분 변경 이벤트 핸들러
 * @param {Event} event onchange event
 */
const handleChangeTestType = (event) => {
    selectedTestType = event.target.value;
    validateAddTemplate();
    console.log("test type changed", event.target.value);
};

/**
 * @description 템플릿 추가 핸들러
 * @param {Event} event onclick event
 */
const handleAddTemplate = async (event) => {
    showLoading();
    console.log(uploadedTemplate);
    const data = new FormData();
    data.append("tester-select", selectedTester);
    data.append("test-item-select", selectedTestItem);
    data.append("test-type-select", selectedTestType);
    data.append("file", uploadedTemplate);
    const result = await fetch(POST_PARSER_CONFIG, {
        method: "post",
        body: data,
    })
        .then((response) => response.json())
        .then((data) => data)
        .catch((error) => console.log("error:", error));
    const { Code, Data, Message } = result;
    if (Code === "SUCCESS") {
        const { TemplateId } = Data;
        console.log(Data);
        moveToSettingsDetail(TemplateId);
    } else {
        alert(`${Message}`);
    }
    hideLoading();
};

/**
 * @description 템플릿 수정 핸들러
 * @param {Event} event onclick event
 */
const handleEditTemplate = async (event) => {
    showLoading();
    console.log(templateList[selectedTemplateIndex]);
    const { TemplateId, UploadId } = templateList[selectedTemplateIndex];
    const data = new FormData();
    data.append("templateId", TemplateId);
    data.append("tester-select", selectedTester);
    data.append("test-item-select", selectedTestItem);
    data.append("test-type-select", selectedTestType);
    data.append("file", uploadedTemplate);

    const result = await fetch(POST_PARSER_CONFIG_UPDATE, {
        method: "post",
        body: data,
    })
        .then((response) => response.json())
        .then((data) => data)
        .catch((error) => console.log("error:", error));
    const { Code, Data, Message } = result;
    if (Code === "SUCCESS") {
        const { TemplateId, UploadId } = Data;
        console.log(Data);
        moveToTemplateEdit(TemplateId, UploadId);
    } else {
        alert(`${Message}`);
    }
    hideLoading();

    hideLoading();
};

/**
 * @description 템플릿 삭제 핸들러
 * @param {Event} event onclick event
 */
const handleRemoveTemplate = async (event) => {
    if (window.confirm("정말로 삭제하시겠습니까?")) {
        showLoading();
        const result = await fetch(`${DELETE_PARSER_CONFIG}/${selectedTemplateId}`)
            .then((response) => response.json())
            .then((data) => data);
        console.log(result);
        const { Code } = result;
        if (Code === "SUCCESS") {
            await getTemplateList();
            selectedTemplateIndex = -1;
            selectedTemplateId = null;
            $testerSelect.value = "";
            $testItemSelect.value = "";
            $testTypeSelect.value = "";
            $templateUploadInput.value = "";
            $editTemplate.disabled = true;
            $removeTemplate.disabled = true;
            alert("템플릿 삭제가 완료되었습니다");
        } else {
            alert("템플릿 삭제에 실패했습니다\n다시 시도해주세요");
        }

        hideLoading();
    }
};

(function () {
    $templateSelect = document.getElementById("template-select");
    $addTemplate = document.getElementById("add-template");
    $editTemplate = document.getElementById("edit-template");
    $removeTemplate = document.getElementById("remove-template");
    $templateUploadInput = document.getElementById("template-upload-input");
    $templateFile = document.getElementById("template-file");
    $testerSelect = document.getElementById("tester-select");
    $testItemSelect = document.getElementById("test-item-select");
    $testTypeSelect = document.getElementById("test-type-select");
    uploadedTemplate === undefined;
    $templateFile.value = "";

    getTemplateList();

    getTesterList();

    getTestItemList();

    getTestTypeList();
})();

window.onload = function () {
    $templateSelect.addEventListener("change", handleChangeTemplate);

    $templateFile.addEventListener("change", handleUploadTemplate);

    $testerSelect.addEventListener("change", handleChangeTester);

    $testItemSelect.addEventListener("change", handleChangeTestItem);

    $testTypeSelect.addEventListener("change", handleChangeTestType);

    $addTemplate.addEventListener("click", handleAddTemplate);

    $editTemplate.addEventListener("click", handleEditTemplate);

    $removeTemplate.addEventListener("click", handleRemoveTemplate);
};

// id="template-upload-button"
// type="button"
