﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using tasco_pdf.Models;
using tasco_pdf.Models.Service;

namespace tasco_pdf.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        //PDF 파서 메인화면
        public IActionResult Main()
        {
            return View();
        }

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}