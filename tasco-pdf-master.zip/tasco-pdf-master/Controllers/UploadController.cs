﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using tasco_pdf.Common;
using tasco_pdf.Models.Service;

namespace tasco_pdf.Controllers
{
    public class UploadController : Controller
    {
        Result result = new Result();
        JsonParser jsonParser = new JsonParser();
        FileService fileService = new FileService();
        


        public ActionResult UploadFile()
        {
            IFormCollection form = HttpContext.Request.Form;
            

            IFormFile pdfFile = form.Files.First();
            Console.WriteLine("FileName: " + pdfFile.FileName);

            foreach (var key in form.Keys)
            {
                var val = HttpContext.Request.Form[key];
                Console.WriteLine(key + ": " + val);
            }

            return View();
        }


        /*
        public ActionResult UploadFile(IFormCollection formCollection, IEnumerable<IFormFile> uploadFiles)
        {
            string tester = formCollection["tester"];
            string testitem = formCollection["testitem"];
            string testType = formCollection["testType"];

            Console.WriteLine("tester: ", tester);
            Console.WriteLine("testitem: ", testitem);
            Console.WriteLine("testType: ", testType);
            
            foreach (IFormFile uploadFile in uploadFiles)
            {
                Console.WriteLine("file.Name: ", uploadFile.FileName);
            }

            return View();
        }
        */

        /*
        public ActionResult UploadFile(IEnumerable<IFormFile> files, string tester, string testitem, string testType)
        {
            foreach (var file in files)
            { 
                Console.WriteLine(file.Name);
            }
              
            Console.WriteLine("tester: ", tester);
            Console.WriteLine("testitem: ", testitem);
            Console.WriteLine("testType: ", testType);

            try 
            {
                long size = files.Sum(f => f.Length);
                if ( files == null || size == 0 ) 
                {                    
                    result.setCode("ERROR");
                    result.setMessage("업로드 파일이 없습니다.");

                    return this.Content(jsonParser.toJsonString(result), "application/json");
                }

                //Task<Result> task = fileService.FileProcess(files);

            } 
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);

            }

            return View();
        }

        public IActionResult Index()
        {
            return View();
        }
        */
    }
}
