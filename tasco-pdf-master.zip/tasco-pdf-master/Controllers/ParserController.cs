﻿using iText.Layout.Element;
using Microsoft.AspNetCore.Mvc;
using tasco_pdf.Common;
using tasco_pdf.Models.Dao;
using tasco_pdf.Models.Service;
using static iText.StyledXmlParser.Jsoup.Select.Evaluator;

namespace tasco_pdf.Controllers
{
    public class ParserController : Controller
    {
        private readonly ILogger<ParserController> _logger;
        private readonly IWebHostEnvironment _host;

        private DataService dataService = new DataService();
        private FileService fileService = new FileService();
        private PdfTextService pdfTextService = new PdfTextService();
        private PdfImageService pdfImageService = new PdfImageService();

        TemplateInfo templateInfo = new TemplateInfo();
        JsonParser jsonParser = new JsonParser();
        private Result result = new Result();

        public IActionResult ParserProcess(String templateId, String uploadId)
        {
            result.Clear();
            result.Code = "SUCCESS";

            if (templateId == null || templateId == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "템플릿 ID 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            if (uploadId == null || uploadId == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "업로드 ID 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            ParserInfo parserInfo = dataService.GetTemplateInfo(templateId);
            UploadInfo uploadInfo = dataService.GetUploadInfo(uploadId);

            // 템플릿 파일정보 업로드 파일 정보로 변경
            parserInfo.OrgFilename = uploadInfo.OrgFilename;
            parserInfo.DestFilename = uploadInfo.DestFilename;
            parserInfo.WebPath = uploadInfo.WebPath;
            pdfImageService.GetPdfSize(parserInfo);

            //영역 정보 조회
            List<PdfList> pdfList = dataService.GetTemplateAreaInfo(templateId);
            Result areaResult = new Result();
            for (int i = 0; i < pdfList.Count; i++)
            {
                foreach (PdfAreaInfo pdfAreaInfo in pdfList[i].PdfAreaList)
                {
                    parserInfo.TemplateId = pdfAreaInfo.TemplateId;
                    if (pdfAreaInfo.AreaType == "TEXT")
                    {
                        areaResult = pdfTextService.GetPdfData(parserInfo, pdfAreaInfo.AreaX, pdfAreaInfo.AreaY, pdfAreaInfo.AreaWidth, pdfAreaInfo.AreaHeight, pdfAreaInfo.PdfPage);
                    }
                    else
                    {
                        areaResult = pdfImageService.GetPdfData(parserInfo, pdfAreaInfo.AreaX, pdfAreaInfo.AreaY, pdfAreaInfo.AreaWidth, pdfAreaInfo.AreaHeight, pdfAreaInfo.PdfPage);
                    }

                    pdfAreaInfo.AreaData = (String)areaResult.Data;
                }
            }

            parserInfo.PdfList = pdfList;
            result.Data = parserInfo;
            return this.Content(jsonParser.toJsonString(result), "application/json");
        }

        public IActionResult ParserPDFDelete(String? uploadId)
        {
            result.Clear();
            result.Code = "SUCCESS";

            if (uploadId == null || uploadId == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "업로드 ID 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            int rtnVal = dataService.RemoveUploadInfo(uploadId);
            if (rtnVal < 0)
            {
                result.Code = "ERROR";
                result.Message = "업로드 파일 삭제 오류!";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            return this.Content(jsonParser.toJsonString(result), "application/json");
        }


        [HttpPost]
        public IActionResult ParserPDFUpload([FromForm] IFormCollection formCollection)
        {
            result.Clear();
            result.Code = "SUCCESS";

            FormFileCollection fileCollection = (FormFileCollection)formCollection.Files;
            long fileSize = fileCollection.Sum(f => f.Length);
            if (fileSize == 0)
            {
                result.Code = "ERROR";
                result.Message = "PDF 파일이 업로드 되지 않았습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            // 업로드 파일 정보 저장
            Result fileResult = null;
            foreach (IFormFile file in fileCollection)
            {
                //Console.WriteLine("_host.WebRootPath: " + _host.WebRootPath);
                fileResult = fileService.FileProcess(_host.WebRootPath, file);
            }

            if (fileResult != null)
            {
                if (fileResult.Code == "ERROR")
                {
                    result.Code = "ERROR";
                    result.Message = "파일 업로드 오류!";
                    return this.Content(jsonParser.toJsonString(result), "application/json");
                }

                // 파일 UploadId 설정
                UploadInfo uploadInfo = (UploadInfo)fileResult.Data;
                Dictionary<string, string> rtnVal = new Dictionary<string, string>();
                rtnVal.Add("UploadId", uploadInfo.UploadId);

                result.Data= rtnVal;
            }

            return this.Content(jsonParser.toJsonString(result), "application/json");
        }

        public IActionResult ParserDelete(String? id)
        {
            result.Clear();
            result.Code = "SUCCESS";

            if (id == null || id == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "템플릿 ID 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            int rtnVal = dataService.RemoveTemplateInfo(id);
            if (rtnVal < 0)
            {
                result.Code = "ERROR";
                result.Message = "템플릿 삭제 오류!";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            return this.Content(jsonParser.toJsonString(result), "application/json");
        }

        // 시험 분석서 목록 조회 (사용자 아이디 필요?)
        public IActionResult ParserList(String userId)
        {
            result.Clear();
            result.Code = "SUCCESS";

            /*
            if (userId == null || userId == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "사용자 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }
            */

            result.Data = dataService.GetTemplateListInfo(userId);
            return this.Content(jsonParser.toJsonString(result), "application/json");
        }

        //시험 분석서 [템플릿] 수정
        [HttpPost]
        public IActionResult ParserConfigUpdate(TemplateInfo templateInfo, [FromForm] IFormCollection formCollection)
        {
            result.Clear();
            result.Code = "SUCCESS";
            int rtnVal = -1;

            if (templateInfo.TemplateId == null || templateInfo.TemplateId == String.Empty) 
            {
                result.Code = "ERROR";
                result.Message = "템플릿 ID 정보가 없습니다.";

                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            if (templateInfo.Tester == null || templateInfo.Tester == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "시험기기 정보가 없습니다.";

                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            if (templateInfo.TestItem == null || templateInfo.TestItem == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "시험항목 정보가 없습니다.";

                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            if (templateInfo.TestType == null || templateInfo.TestType == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "시험구분 정보가 없습니다.";

                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            // 기존 템플릿 정보 확인
            // 기존 templateId와 조회 templateId가 동일한 경우 확인 안함

            string templateId = dataService.CheckTemplateInfo(templateInfo.Tester, templateInfo.TestItem, templateInfo.TestType);
            if (!templateInfo.TemplateId.Equals(templateId)) 
            {
                if (templateId != null && templateId != String.Empty)
                {
                    result.Code = "ERROR";
                    result.Message = "기존 템플릿 정보가 있습니다.";
                    result.Etc.Add("templateId", templateId);

                    return this.Content(jsonParser.toJsonString(result), "application/json");
                }
            }
            
            // UploadId 설정
            ParserInfo parserInfo = dataService.GetTemplateInfo(templateInfo.TemplateId);
            templateInfo.UploadId = parserInfo.UploadId;

            // 업로드 파일 정보 확인, 업로드 파일이 없는 경우 기존 uploadId 설정
            FormFileCollection fileCollection = (FormFileCollection)formCollection.Files;
            long fileSize = fileCollection.Sum(f => f.Length);
            if (fileSize != 0)
            {
                // 기존 업로드 파일 정보 삭제
                rtnVal = dataService.RemoveUploadInfo(templateInfo.UploadId);
                if (rtnVal < 0)
                {
                    result.Code = "ERROR";
                    result.Message = "업로드 파일 삭제 오류!";
                    return this.Content(jsonParser.toJsonString(result), "application/json");
                }

                // 업로드 파일 정보 저장
                Result fileResult = null;
                foreach (IFormFile file in fileCollection)
                {
                    //Console.WriteLine("_host.WebRootPath: " + _host.WebRootPath);
                    fileResult = fileService.FileProcess(_host.WebRootPath, file);
                }

                if (fileResult != null)
                {
                    if (fileResult.Code == "ERROR")
                    {
                        result.Code = "ERROR";
                        result.Message = "파일 업로드 오류!";
                        return this.Content(jsonParser.toJsonString(result), "application/json");
                    }

                    // 파일 UploadId 설정
                    UploadInfo uploadInfo = (UploadInfo)fileResult.Data;
                    templateInfo.UploadId = uploadInfo.UploadId;
                }
            }

            rtnVal = dataService.SetTemplateInfo(templateInfo);
            if (rtnVal < 0)
            {
                result.Code = "ERROR";
                result.Message = "템플릿 기본정보 수정 오류!";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            result.Data = templateInfo;
            return this.Content(jsonParser.toJsonString(result), "application/json");
        }

        //시험 분석서 [템플릿] 기본 정보 저장
        [HttpPost]
        public IActionResult ParserConfigSave([FromForm] IFormCollection formCollection)
        {
            result.Code = "SUCCESS";

            var tester = String.Empty;
            var testItem = String.Empty;
            var testType = String.Empty;
            var templateId = String.Empty;
            var uploadId = String.Empty;

            if (formCollection.ContainsKey("tester-select") && formCollection["tester-select"] != String.Empty)
            {
                tester = formCollection["tester-select"];
            }
            else 
            {
                result.Code = "ERROR";
                result.Message = "시험기기 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }
            
            if (formCollection.ContainsKey("test-item-select") && formCollection["test-item-select"] != String.Empty)
            {
                testItem = formCollection["test-item-select"];
            }
            else
            {
                result.Code = "ERROR";
                result.Message = "시험항목 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }
            
            if (formCollection.ContainsKey("test-type-select") && formCollection["test-type-select"] != String.Empty)
            {
                testType = formCollection["test-type-select"];
            }
            else
            {
                result.Code = "ERROR";
                result.Message = "시험구분 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }


            // 기존 템플릿 정보 확인
            templateId = dataService.CheckTemplateInfo(tester, testItem, testType);
            if (templateId != null && templateId != String.Empty) 
            {
                result.Code = "ERROR";
                result.Message = "기존 템플릿 정보가 있습니다.";
                result.Etc.Add("templateId", templateId);

                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            // uploadId 확인 uploadId 가 존재하는 경우 파일 업로드 진행 안함
            if (formCollection.ContainsKey("uploadId") && formCollection["uploadId"] != String.Empty)
            {
                uploadId = formCollection["uploadId"];
                templateInfo.UploadId = uploadId;
            }
            else 
            {
                FormFileCollection fileCollection = (FormFileCollection)formCollection.Files;
                long fileSize = fileCollection.Sum(f => f.Length);
                if (fileSize == 0)
                {
                    result.Code = "ERROR";
                    result.Message = "PDF 파일이 업로드 되지 않았습니다.";
                    return this.Content(jsonParser.toJsonString(result), "application/json");
                }

                // 업로드 파일 정보 저장
                Result fileResult = null;
                foreach (IFormFile file in fileCollection)
                {
                    //Console.WriteLine("_host.WebRootPath: " + _host.WebRootPath);
                    fileResult = fileService.FileProcess(_host.WebRootPath, file);
                }

                if (fileResult != null)
                {
                    if (fileResult.Code == "ERROR")
                    {
                        result.Code = "ERROR";
                        result.Message = "파일 업로드 오류!";
                        return this.Content(jsonParser.toJsonString(result), "application/json");
                    }

                    // 파일 UploadId 설정
                    UploadInfo uploadInfo = (UploadInfo)fileResult.Data;
                    templateInfo.UploadId = uploadInfo.UploadId;
                }
            }

            templateInfo.Tester = tester;
            templateInfo.TestItem = testItem;
            templateInfo.TestType = testType;

            int rtnVal = dataService.SetTemplateInfo(templateInfo);
            if (rtnVal < 0)
            {
                result.Code = "ERROR";
                result.Message = "템플릿 기본정보 저장 오류!";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            result.Data = templateInfo;
            return this.Content(jsonParser.toJsonString(result), "application/json");
        }

        //시험 분석서 템플릿 영역정보 수정 화면
        public IActionResult PdfAreaEdit() { return View(); }

        //시험 분석서 템플릿 영역정보 설정 화면
        public IActionResult PdfArea() { return View(); }
        //시험 분석서 템플릿 기본정보 설정 화면
        public IActionResult ParserConfig() { return View(); }

        //시험 분석서 결과 화면
        public IActionResult ParserResult() { return View(); }
        //시험 분석서 화면 (템플릿 선택 및 PDF 업로드)
        public IActionResult ParserInfo() { return View(); }

        public ParserController(ILogger<ParserController> logger, IWebHostEnvironment host)
        {
            _logger = logger;
            _host = host;
        }
    }
}
