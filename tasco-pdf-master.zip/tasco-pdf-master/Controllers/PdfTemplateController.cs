﻿using Microsoft.AspNetCore.Mvc;
using System.Security.AccessControl;
using System;
using tasco_pdf.Common;
using tasco_pdf.Models.Dao;
using tasco_pdf.Models.Service;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Linq;
using System.Text;
using tasco_pdf.Models.Common;
using Newtonsoft.Json;

namespace tasco_pdf.Controllers
{

    public class PdfTemplateController : Controller
    {
        private readonly ILogger<PdfTemplateController> _logger;

        private DataService dataService = new DataService();
        private PdfTextService pdfTextService = new PdfTextService();
        private PdfImageService pdfImageService = new PdfImageService();

        TemplateInfo templateInfo = new TemplateInfo();
        JsonParser jsonParser = new JsonParser();
        private Result result = new Result();

        // 템플릿 영역 설정 화면 조회 (조회 시 PDF 파싱)
        public IActionResult ParserAreaLoad(String? id)
        {
            result.Clear();
            result.Code = "SUCCESS";

            if (id == null || id == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "템플릿 ID 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            List<PdfList> pdfList = dataService.GetTemplateAreaInfo(id);

            // 파싱 정보 추가
            ParserInfo parserInfo = new ParserInfo();
            Result areaResult = new Result();

            for (int i = 0; i < pdfList.Count; i++) 
            {
                foreach (PdfAreaInfo pdfAreaInfo in pdfList[i].PdfAreaList)
                {
                    parserInfo.TemplateId = pdfAreaInfo.TemplateId;
                    if (pdfAreaInfo.AreaType == "TEXT")
                    {
                        areaResult = pdfTextService.GetPdfData(parserInfo, pdfAreaInfo.AreaX, pdfAreaInfo.AreaY, pdfAreaInfo.AreaWidth, pdfAreaInfo.AreaHeight, pdfAreaInfo.PdfPage);
                    }
                    else
                    {
                        areaResult = pdfImageService.GetPdfData(parserInfo, pdfAreaInfo.AreaX, pdfAreaInfo.AreaY, pdfAreaInfo.AreaWidth, pdfAreaInfo.AreaHeight, pdfAreaInfo.PdfPage);
                    }

                    pdfAreaInfo.AreaData = (String)areaResult.Data;
                }
            }

            return this.Content(jsonParser.toJsonString(pdfList), "application/json");
        }

        //템플릿 영역 설정 화면 저장
        [HttpPost]
        public IActionResult ParserAreaSave([FromBody][ModelBinder(BinderType = typeof(GetModelBindingContext))] string json)
        //public IActionResult ParserAreaSave([FromBody]ParserAreaInfo parserAreaInfo)
        //public IActionResult ParserAreaSave(PdfAreaInfo[] parserAreaList, [FromForm] IFormCollection formCollection, String templateId, String[] testKey, String[] areaType, float[] areaX, float[] areaY, float[] areaWidth, float[] areaHeight)
        {
            result.Clear();
            result.Code = "SUCCESS";

            if (json == null || json == String.Empty)
            {
                result.Code = "ERROR";
                result.Message = "템플릿 영역 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            var parserAreaInfo = JsonConvert.DeserializeObject<ParserAreaInfo>(json);
            if (parserAreaInfo == null || parserAreaInfo.pageList == null || parserAreaInfo.pageList.Count == 0)
            {
                result.Code = "ERROR";
                result.Message = "템플릿 영역 정보가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            List<PdfAreaInfo> pdfAreaInfos = new List<PdfAreaInfo>(); // 저장용
            for (int i = 0; i < parserAreaInfo.pageList.Count; i++) 
            {
                int AreaOrder = 1;
                foreach (ParserAreaDetail parserAreaDetail in parserAreaInfo.pageList[i].parserAreaList)
                {
                    PdfAreaInfo pdfAreaInfo = new PdfAreaInfo();
                    pdfAreaInfo.TemplateId = parserAreaInfo.templateId;
                    pdfAreaInfo.TestKey = parserAreaDetail.testKey;
                    pdfAreaInfo.AreaType = parserAreaDetail.areaType;
                    pdfAreaInfo.AreaX = (float)parserAreaDetail.areaX;
                    pdfAreaInfo.AreaY = (float)parserAreaDetail.areaY;
                    pdfAreaInfo.AreaWidth = (float)parserAreaDetail.areaWidth;
                    pdfAreaInfo.AreaHeight = (float)parserAreaDetail.areaHeight;
                    pdfAreaInfo.PdfPage = parserAreaInfo.pageList[i].page;
                    pdfAreaInfo.AreaOrder = AreaOrder;

                    pdfAreaInfos.Add(pdfAreaInfo);
                    AreaOrder++;
                }
            }

            int rtnVal = dataService.SetTemplateAreaInfo(pdfAreaInfos);
            if (rtnVal < 0) 
            {
                result.Code = "ERROR";
                result.Message = "템플릿 영역 정보 저장 오류";
            }

            return this.Content(jsonParser.toJsonString(result), "application/json");
        }

        // PDF 영역 자료 추출
        [HttpGet]
        public IActionResult ParserArea(String templateId, String areaType, float areaX, float areaY, float areaWidth, float areaHeight, int page)
        {
            ParserInfo parserInfo = dataService.GetTemplateInfo(templateId);
            pdfImageService.GetPdfSize(parserInfo); // pdf 크기 설정
            
            areaX = (float)Math.Truncate(areaX);
            areaY = (float)Math.Truncate(areaY);
            areaWidth = (float)Math.Truncate(areaWidth);
            areaHeight = (float)Math.Truncate(areaHeight);

            if (areaType == "TEXT")
            {
                result = pdfTextService.GetPdfData(parserInfo, areaX, areaY, areaWidth, areaHeight, page);
            }
            else
            {
                result = pdfImageService.GetPdfData(parserInfo, areaX, areaY, areaWidth, areaHeight, page);
            }

            return this.Content(jsonParser.toJsonString(result), "application/json");
        }

        // 템플릿 기본 정보 조회
        public IActionResult ParserConfigLoad(String? id)
        {
            result.Code = "SUCCESS";

            if (id == null || id == String.Empty) 
            {
                result.Code = "ERROR";
                result.Message = "템플릿 아이디가 없습니다.";
                return this.Content(jsonParser.toJsonString(result), "application/json");
            }

            ParserInfo parserInfo = dataService.GetTemplateInfo(id);
            pdfImageService.GetPdfSize(parserInfo);

            // webPath 설정 필요

            String destFilename = parserInfo.DestFilename;


            result.Data = parserInfo;
            return this.Content(jsonParser.toJsonString(result), "application/json");
        }

        public PdfTemplateController(ILogger<PdfTemplateController> logger)
        {
            _logger = logger;
        }

    }
}
