﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using tasco_pdf.Common;
using tasco_pdf.Models;
using tasco_pdf.Models.Service;

namespace tasco_pdf.Controllers
{
    public class DataController : Controller
    {
        private readonly ILogger<DataController> _logger;

        /// <summary>
        /// combo 자료 조회
        /// </summary>
        DataService dataServcie = new DataService();
        JsonParser jsonParser = new JsonParser();

        //추출 이미지 key 목록
        [HttpGet]
        public IActionResult TestImageKeyList()
        {
            object rtnVal = dataServcie.getTestImageKeyList();
            return this.Content(jsonParser.toJsonString(rtnVal), "application/json");
        }

        //추출 key 목록
        [HttpGet]
        public IActionResult TestKeyList()
        {
            object rtnVal = dataServcie.getTestKeyList();
            return this.Content(jsonParser.toJsonString(rtnVal), "application/json");
        }

        //시험 구분 목록
        [HttpGet]
        public IActionResult TestTypeList()
        {
            object rtnVal = dataServcie.getTestTypeList();
            return this.Content(jsonParser.toJsonString(rtnVal), "application/json");
        }

        //시험 유형 목록
        [HttpGet]
        public IActionResult TestItemList()
        {
            object rtnVal = dataServcie.getTestItemList();
            return this.Content(jsonParser.toJsonString(rtnVal), "application/json");
        }

        //시험 기기 목록
        [HttpGet]
        public IActionResult TesterList()
        {
            object rtnVal = dataServcie.getTesterList();
            return this.Content(jsonParser.toJsonString(rtnVal), "application/json");
        }

        public DataController(ILogger<DataController> logger)
        {
            _logger = logger;
        }

        /*
        private readonly RtegmsContext _rtegmsContext;

        public DataController(RtegmsContext rtegmsContext)
        {
            this._rtegmsContext = rtegmsContext;
        }

        public async Task<IActionResult> TesterList()
        {
            return View(await _rtegmsContext.testers.ToListAsync());
        }

        public async Task<IActionResult> TestItemList()
        {
            return View(await _rtegmsContext.testitemmasters.ToListAsync());
        }
        */
    }
}
