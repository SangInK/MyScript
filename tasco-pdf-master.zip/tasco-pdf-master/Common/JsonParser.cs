﻿using iText.Layout.Element;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;

namespace tasco_pdf.Common
{
    public class JsonParser
    {
        private JsonSerializerOptions _options;
        public JsonParser() 
        {
            _options = new JsonSerializerOptions
            {
                Encoder = JavaScriptEncoder.Create(UnicodeRanges.BasicLatin, UnicodeRanges.HangulSyllables),
            };
        }

        public string toJsonString(object obj) 
        {
            string rtnVal = string.Empty;

            rtnVal = JsonSerializer.Serialize(obj, _options);
            //Console.WriteLine(rtnVal);

            return rtnVal;
        }
    }
}
