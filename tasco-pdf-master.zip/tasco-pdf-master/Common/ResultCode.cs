﻿namespace tasco_pdf.Common
{
    public enum ResultCode
    {
        SUCCESS = 0000,
        ERROR = 9999
    }
}
