﻿using System.Collections.Generic;

namespace tasco_pdf.Common
{
    public class Result
    {
        public string Code { get; set; }

        public string Message { get; set; }

        public object Data { get; set; }

        public Dictionary<string, string> Etc { get; set; }

        public void Clear()
        { 
            this.Code = String.Empty;
            this.Message = String.Empty;
            this.Etc = new Dictionary<string, string>();
        }

        public Result() 
        {
            Etc = new Dictionary<string, string>();
        }
    }
}
